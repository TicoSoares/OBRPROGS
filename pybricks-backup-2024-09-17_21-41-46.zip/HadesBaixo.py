from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor
from pybricks.parameters import Button, Color, Direction, Port
from pybricks.robotics import DriveBase
from pybricks.tools import wait, multitask, run_task

from ExtraTools import *

# Define as Portas
sensorD = ColorSensor(Port.A)
sensorE = ColorSensor(Port.B)
ultra = UltrasonicSensor(Port.D)
motorD = Motor(Port.C)
motorE = Motor(Port.E, Direction.COUNTERCLOCKWISE)

colors = {
    "green": Color.GREEN,
    "prata": Color.GRAY,
    "red": Color.RED,
    "preto": Color.BLACK,
    "branco": Color.WHITE
}
colors_copy = colors.copy()
colors_array = ["green", "prata", "red", "branco"]

integral = 0
last_error = 0

vermelho = False

forcaBase = 183
_KP = 10  # Este valor será ajustado para encontrar K_u
_KI = 0
_KD = 2.0

# Define motores de movimento
drive = DriveBase(motorE, motorD, wheel_diameter=40, axle_track=200)
# drive.settings(forcaBase, 120, 350, 210)
drive.settings(forcaBase)
defaultSettings = drive.settings()

def AnotaCor():
    global colors_note

    Send("ESTADO", Estado.COR)
    hub.display.off()

    menu_keys = colors_array
    menu_index = 0

    selected = menu_keys[menu_index]
    hub.light.on(colors_copy[selected])

    array_colors = hub.system.storage(0, read=20)  # Inicializa o bytearray com tamanho 20

    while True:
        result = GetButton()
        pressed = time_pressed = None
        if result is None:
            break
        else:
            pressed, time_pressed = result

        if result is not None:
            pressed, time_pressed = result
            if Button.CENTER in pressed:
                if time_pressed > 1000:
                    hub.system.storage(0, write=array_colors)
                    print(hub.system.storage(0, read=20))
                    break
                else:
                    colorE = sensorE.hsv()
                    colorD = sensorD.hsv()

                    if selected == "branco":
                        print("branco :", colorE, "preto :", colorD)
                        array_colors = array_colors[:12] + hsv_to_bytes(colorD) + hsv_to_bytes(colorE)
                    else:
                        start_index = menu_index * 4
                        array_colors = array_colors[:start_index] + hsv_to_bytes(colorD) + array_colors[start_index + 4:]
                        print(selected, ":", colorD)

            elif Button.LEFT in pressed:
                menu_index = (menu_index - 1) % len(menu_keys)
            elif Button.RIGHT in pressed:
                menu_index = (menu_index + 1) % len(menu_keys)

            selected = menu_keys[menu_index]
            hub.light.on(colors_copy[selected])

def LadoObstaculo():
    hub.display.off()

    while True:
        result = GetButton()
        pressed = time_pressed = None
        if result is None:
            break
        else:
            pressed, time_pressed = result

        if result is not None:
            pressed, time_pressed = result
            if Button.CENTER in pressed:
                break
            elif Button.RIGHT in pressed:
                hub.system.storage(20, write=bytes([1]))
                break
            elif Button.LEFT in pressed:
                hub.system.storage(20, write=bytes([0]))
                break

def ComparaHsv(hsv, color_name, sens=20):
    color = colors[color_name]
    hresult = abs(hsv.h - color.h) <= sens
    sresult = abs(hsv.s - color.s) <= sens
    vresult = abs(hsv.v - color.v) <= sens
    return hresult and sresult and vresult

def ChecaVerde():
    eColor = sensorE.hsv()
    dColor = sensorD.hsv()
    pitch = hub.imu.tilt()[0]
    if (ComparaHsv(eColor, "green") or ComparaHsv(dColor, "green")) and -5 < pitch < 5:
        print("verde")
        hub.speaker.beep(1000, 200)
        drive.stop()
        wait(500)
        drive.drive(60, 0)
        if ComparaHsv(eColor, "green") and ComparaHsv(dColor, "green"):
            print("verde BECO")
            VerdeVerde()
        
        elif ComparaHsv(eColor, "green"):
            drive.turn(-15)
            drive.drive(60, 0)
            while True:
                # Verifica dnv se é verde verde caso tenha passado e n viu
                if ComparaHsv(sensorD.hsv(), "green"):
                    print("verde verde")
                    VerdeVerde()
                    break
                if not ComparaHsv(sensorE.hsv(), "green"):
                    if ComparaHsv(sensorE.hsv(), "branco", 18):
                        drive.turn(25)
                        print("branco")
                        break
                    elif ComparaHsv(sensorE.hsv(), "preto", 18):
                        Send("OCUPADO", 1)
                        SendBLE()
                        print("preto")
                        drive.straight(40)
                        drive.turn(30)
                        GiraAtePreto(120, 150, sensorE)
                        drive.turn(15)
                        wait(10)
                        break
                wait(50)

        elif ComparaHsv(dColor, "green"):
            drive.settings(defaultSettings[0], defaultSettings[1], 300)
            drive.turn(15)
            drive.drive(60, 0)
            
            drive.settings(forcaBase)

            while True:
                # Verifica dnv se é verde verde caso tenha passado e n viu
                if ComparaHsv(sensorE.hsv(), "green"):
                    print("verde verde")
                    VerdeVerde()
                    break
                if not ComparaHsv(sensorD.hsv(), "green"):
                    if ComparaHsv(sensorD.hsv(), "branco", 18):
                        drive.turn(-25)
                        print("branco")
                        break
                    elif ComparaHsv(sensorD.hsv(), "preto", 18):
                        Send("OCUPADO", 1)
                        SendBLE()
                        print("preto")
                        drive.straight(40)
                        drive.turn(-30)
                        GiraAtePreto(-120, 150, sensorD)
                        drive.turn(-15)
                        wait(10)
                        break
                wait(50)
def VerdeVerde():
    print("beco")
    while True:
        if not ComparaHsv(sensorD.hsv(), "green"):
            if ComparaHsv(sensorD.hsv(), "branco", 18):
                print("branco")
                break
            elif ComparaHsv(sensorD.hsv(), "preto", 18):
                Send("OCUPADO", 1)
                SendBLE()
                print("preto")
                drive.straight(30)
                drive.turn(-180)
                # GiraAtePreto(-150, 150, sensorD)
                # drive.turn(-15)
                drive.straight(20)
                wait(10)
                break
        wait(10)

def ChecaVermelho():
    global vermelho
    eColor = sensorE.hsv()
    dColor = sensorD.hsv()
    # print("E: ", ComparaHsv(eColor, "red", 20), "D: ", ComparaHsv(dColor, "red", 20))
    pitch = hub.imu.tilt()[0]
    # print("pitch: ", pitch)
    if ComparaHsv(eColor, "red") and ComparaHsv(dColor, "red") and -5 < pitch < 5:
        hub.speaker.beep(850, 200)
        vermelho = True
        return True
    return False

def ChecaObstaculo(lado=1):
    Send("OCUPADO", 1)
    SendBLE()
    pitch = hub.imu.tilt()[0]
    distancia = ultra.distance()
    ultra_factor = 0.0
    if distancia < 50:
        drive.brake()
        wait(100)
        if ultra.distance() <= 50:
            drive.stop()
            drive.turn(-90 * lado)
            drive.straight(220)
            drive.turn(91 * lado)
            x = 3
            for _ in range(x):
                if MoveAtePreto(210, 210, 250, sensorE, sensorD):
                    drive.straight(69)
                    drive.turn(-45 * lado)
                    if lado == 1:
                        GiraAtePreto(-150, 150, sensorD)
                    else:
                        GiraAtePreto(150, 150, sensorE)

                    drive.turn(-15 * lado)
                    drive.straight(-25)
                    drive.stop()
                    return
                else:
                    drive.straight(180)
                    drive.turn(90 * lado)
    Send("OCUPADO", 0)

def Pid():
    global integral, last_error
    erro = sensorE.reflection() - sensorD.reflection()
    if abs(erro) < 10 and sensorD.reflection() > 50:
        erro = 0
    proporcional = erro * _KP
    integral += erro * _KI
    derivado = (erro - last_error) * _KD
    correcao = proporcional + integral + derivado
    motorE.run((forcaBase - abs(erro) * 1.1) - correcao)
    motorD.run((forcaBase - abs(erro) * 1.1) + correcao)
    last_error = erro

def MoveAtePreto(speed_left, speed_right, distance, sensorA, sensorB = None):
    motorE.reset_angle(0)
    motorD.reset_angle(0)

    #target_angle = distance * (360 / (3.1416 * 36))
    target_angle = distance * 3.19

    while abs(motorE.angle()) < target_angle and abs(motorD.angle()) < target_angle:
        if sensorB == None:
            if ComparaHsv(sensorA.hsv(), "preto"):
                return True
        else:
            if ComparaHsv(sensorA.hsv(), "preto") or ComparaHsv(sensorB.hsv(), "preto"):
                return True
        motorE.run(speed_left)
        motorD.run(speed_right)

    motorE.stop()
    motorD.stop()
    return False

def GiraAtePreto(speed, distance, sensorA, sensorB = None):
    motorE.reset_angle(0)
    motorD.reset_angle(0)

    target_angle = distance * (360 / (3.1416 * 36))

    while abs(motorE.angle()) < target_angle and abs(motorD.angle()) < target_angle:
        if sensorB == None:
            if ComparaHsv(sensorA.hsv(), "preto"):
                break
        else:
            if ComparaHsv(sensorA.hsv(), "preto") or ComparaHsv(sensorB.hsv(), "preto"):
                break
        motorE.run(speed)
        motorD.run(-speed)

    hub.speaker.beep(900, 200)
    motorE.stop()
    motorD.stop()

def RetaUltra(speed_left, speed_right, distance, ultraDist, factor, sensorA, sensorB = None):
    motorE.reset_angle(0)
    motorD.reset_angle(0)

    target_angle = distance * (360 / (3.1416 * 36))
    # target_angle = distance * 3.19

    ultra_factor = 0.0

    while distance == 0 or (abs(motorE.angle()) < target_angle and abs(motorD.angle()) < target_angle ):
        # angle_percorrido = (abs(motorE.angle()) + abs(motorD.angle())) / 2
        # dist_percorrida = angle_percorrido / 3.19

        if sensorB == None:
            if ComparaHsv(sensorA.hsv(), "preto", 18):
                drive.stop()
                print("preto")
                return "Preto"
        else:
            if ComparaHsv(sensorA.hsv(), "preto", 18) or ComparaHsv(sensorB.hsv(), "preto", 18):
                drive.stop()
                print("preto")
                return "Preto"

        if ultra.distance() <= ultraDist:
            ultra_factor += 1
            if ultra_factor > factor:
                drive.stop()
                drive.straight(50)
                print("parede")
                return "Parede"
        else:
            ultra_factor = 0

        motorE.run(speed_left)
        motorD.run(speed_right)
        wait(100)

    drive.stop()
    print("distancia")
    return "Distancia"

def RetaInterrompida(speed_left, speed_right, distance, sens, sensorA, sensorB = None):
    motorE.reset_angle(0)
    motorD.reset_angle(0)

    target_angle = distance * (360 / (3.1416 * 36))

    while abs(motorE.angle()) < target_angle and abs(motorD.angle()) < target_angle:
        if sensorB == None:
            if ComparaHsv(sensorA.hsv(), "preto", 18):
                print("preto")
                return "Preto"
        else:
            if ComparaHsv(sensorA.hsv(), "preto", 18) or ComparaHsv(sensorB.hsv(), "preto"):
                print("preto")
                return "Preto"
        if abs(motorE.angle()) > 180:
            diferencaA = abs(abs(motorE.speed()) - abs(speed_left))
            diferencaB = abs(abs(motorD.speed()) - abs(speed_right))
            print("diferencaA: ", diferencaA, "diferencaB: ", diferencaB)
            if diferencaA > sens or diferencaB > sens:
                drive.stop()
                print("saiu")
                wait(1000)
                print("bateu")
                return "Bateu"
        motorE.run(speed_left)
        motorD.run(speed_right)

    drive.stop()
    motorE.stop()
    motorD.stop()
    print("distancia")
    return "Distancia"

def Straight(dist, speed = 2000):
    motorE.reset_angle(0)
    motorD.reset_angle(0)
    
    vel = speed if dist > 0 else -speed

    target_angle = abs(dist) * (360 / (3.1416 * 36))

    while abs(motorE.angle()) < target_angle and abs(motorD.angle()) < target_angle:
        motorE.run(vel)
        motorD.run(vel)
    
def ChecaPrata():
    eColor = sensorE.hsv()
    dColor = sensorD.hsv()
    pitch = hub.imu.tilt()[0]
    if ComparaHsv(eColor, "prata", 5) and ComparaHsv(dColor, "prata", 5) and -5 < pitch < 5:
        print("prata")
        hub.speaker.beep(1000, 200)
        drive.stop()
        Send("ESTADO", Estado.RESGATE)
        return True
    return False

def giro_preciso(angulo_desejado, velocidade=400):
    angulo_inicial = hub.imu.heading()  # Obtém o ângulo inicial
    angulo_alvo = angulo_inicial - angulo_desejado
    print("inicial: ", angulo_inicial, "alvo: ", angulo_alvo)  # Calcula o ângulo alvo

    while True:
        angulo_atual = hub.imu.heading()  # Atualiza o ângulo atual
        erro = angulo_alvo - angulo_atual 
        print("erro: ", erro) # Calcula o erro

        if abs(erro) < 3:  # Se o erro for menor que 2 graus, parar
            break

        # Controla a velocidade do motor proporcional ao erro
        velocidade_ajustada = velocidade if erro < 0 else -velocidade
        motorE.run(velocidade_ajustada)
        motorD.run(-velocidade_ajustada)
        
        wait(10)

    # Parar os motores
    motorE.stop()
    motorD.stop()
    

def Resgate():
#Verifica se está no meio ou no canto----------------------------------------
    ret_horizontal = 1
    drive.settings(650)
    saidaMeio = 0
    saidasCanto = [0,0]
    drive.straight(220)
    giro_preciso(-90)
    lado = 0
    drive.straight(75)
    wait(250)
    GetBLE()
    print("Frente: ",Read("FRFX"))
    if Read("FRFX") >= 5:
        lado = 1
        drive.straight(100)
        drive.straight(-100)
    else:
        drive.straight(-150)
        wait(250)
        GetBLE()
        print("Tras: ",Read("TRFX"))
        if Read("TRFX") >= 5:
            lado = -1
            drive.straight(-100)
        drive.straight(50)

    print("lado: ", lado)
    giro_preciso(90)
    hub.imu.reset_heading(0)
    giro_preciso(lado * 55)
    drive.straight(350 + abs(lado * 300))
    if not lado == 0:
        giro_preciso(lado * -55)
    else:
        giro_preciso(90)

#Pega vítimas nos meios----------------------------------------

    x = 4
    if lado == 0:
        x = 3
    for _ in range(x):
        Send("GARRA", Garra.ABERTA)
        SendBLE()
        wait(500)
        reta = RetaUltra(500, 500, 0, 175, 2, sensorE, sensorD)
        Send("GARRA", Garra.FECHADA)
        SendBLE()
        wait(1500)

        if reta == "preto":
            saidaMeio = _
            drive.straight(-430)
        else:
            drive.straight(166)
            if _ % 2 == ret_horizontal:
                print("maior")
                drive.straight(-630)
            else:
                print("menor")
                drive.straight(-490)
            
        if not lado == 0 or not _ == 3:
            giro_preciso(-90)
        else:
            giro_preciso(90)

    if lado == -1:
        giro_preciso(45)
    else:
        giro_preciso(-45)
    wait(250)

#Pega vítimas nos CANTOS
    tri_verde = 0
    tri_vermelho = 0
    if not lado == 0:
        x = 3
    for _ in range(x):
        Send("GARRA", Garra.ABERTA)
        SendBLE()
        wait(500)
        # reta = RetaUltra(500, 500, 0, 175, 1, sensorE, sensorD)
        drive.straight(400)
        Send("GARRA", Garra.FECHADA)
        SendBLE()
        wait(1500)
        # if Read("FCOR") == 0:
        #     print("canto vazio")
        #     hub.speaker.beep(1000, 200)
        #     wait(200)
        #     hub.speaker.beep(1000, 200)
        #     wait(200)
        #     hub.speaker.beep(1000, 200)

        #     if saidasCanto[0] == 0:
        #         giro_preciso(-45)
        #         wait(100)
        #         if ultra.distance() >= 120:
        #             saidasCanto[0] = _ 
        #             saidasCanto[1] = -1
        #         giro_preciso(90)
        #         wait(100)
        #         if ultra.distance() >= 120:
        #             saidasCanto[0] = _
        #             saidasCanto[1] = 1
        #         giro_preciso(-45)
        # else:
        RetaInterrompida(500, 500, 140, 30, sensorE, sensorD)
        wait(250)
        GetBLE()
        if not Read("FCOR") == 0:
            drive.straight(140)
            print("canto triangulo")
            if Read("FCOR") == 1:
                tri_verde = _
            elif Read("FCOR") == 2:
                tri_vermelho = _
            drive.straight(-390)
        else:
            hub.speaker.beep(900, 200)
            drive.straight(-610)    

        if lado == 0 and not _ == 4:
            giro_preciso(90)
        elif not lado == 0 and not _ == 3:
            giro_preciso(90 * lado)

    hub.speaker.beep(1000, 200)
    wait(200)
    hub.speaker.beep(1000, 200)

    print("saida meio: ", saidaMeio)
    print("saida canto: ", saidasCanto)

    virada = 0
    if not tri_verde == 0: 
        triangulo = tri_verde
    else:
        triangulo = tri_vermelho
        
    if lado == 0:
        virada = (triangulo - 1) * 90
    else:
        virada = (triangulo - 1) * 90 * lado

    giro_preciso(virada)

    
    drive.straight(-625)
    Send("PORTA", Porta.ABERTA)
    SendBLE()
    wait(1000)
    Straight(100)
    Straight(-100)
    wait(500)
    Send("PORTA", Porta.FECHADA)
    SendBLE()
    drive.straight(320)

    hub.speaker.beep(1000, 200)

    giro_preciso(-90)
    drive.straight(345)
    giro_preciso(45)

    Send("ESTADO", Estado.PLAY)
    SendBLE()

def Seguidor():
    ChecaObstaculo((int.from_bytes(hub.system.storage(20, 1), 'big') * 2) - 1)
    ChecaVerde()
    Send("OCUPADO", 0)
    if not ChecaVermelho():
        if not ChecaPrata():
            Pid()

def Play():
    global integral, last_error, vermelho
    integral = 0
    last_error = 0
    vermelho = False
    GetStoredColors(colors, colors_array)
    Send("ESTADO", Estado.PLAY)

    WaitTheOtherHub()

    while True:
        GetBLE()
        if CheckStopButton() or Read("ESTADO") == Estado.MAIN or vermelho:
            drive.stop()
            break

        if Send("ESTADO") == Estado.PLAY:
            drive.settings(forcaBase)
            Seguidor()
        elif Send("ESTADO") == Estado.RESGATE:
            Resgate()

        SendBLE()
        wait(10)

if __name__ == "__main__":
    # Send("GARRA", Garra.ABERTA)
    # SendBLE()
    while True:
        giro_preciso(90)

        wait(100000)
        
