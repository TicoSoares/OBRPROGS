from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor
from pybricks.parameters import Button, Color, Direction, Port
from pybricks.robotics import DriveBase
from pybricks.tools import wait

from ExtraTools import *

# Define as Portas
sensorD = ColorSensor(Port.A)
sensorE = ColorSensor(Port.B)
ultra = UltrasonicSensor(Port.D)
motorD = Motor(Port.C)
motorE = Motor(Port.E, Direction.COUNTERCLOCKWISE)

colors = {
    "green": Color.GREEN,
    "prata": Color.GRAY,
    "red": Color.RED,
    "preto": Color.BLACK,
    "branco": Color.WHITE
}
colors_copy = colors.copy()
colors_array = ["green", "prata", "red", "branco"]

integral = 0
last_error = 0

forcaBase = 150
_KP = 9.0  # Este valor será ajustado para encontrar K_u
_KI = 0
_KD = 2.0

# Define motores de movimento
drive = DriveBase(motorE, motorD, wheel_diameter=40, axle_track=200)
drive.settings(forcaBase, 100, 350, 210)
drive.settings(forcaBase)

def AnotaCor():
    global colors_note

    Send("ESTADO", Estado.COR)
    hub.display.off()

    menu_keys = colors_array
    menu_index = 0

    selected = menu_keys[menu_index]
    hub.light.on(colors_copy[selected])

    array_colors = hub.system.storage(0, read=20)  # Inicializa o bytearray com tamanho 20

    while True:
        result = GetButton()
        pressed = time_pressed = None
        if result is None:
            break
        else:
            pressed, time_pressed = result

        if result is not None:
            pressed, time_pressed = result
            if Button.CENTER in pressed:
                if time_pressed > 1000:
                    hub.system.storage(0, write=array_colors)
                    print(hub.system.storage(0, read=20))
                    break
                else:
                    colorE = sensorE.hsv()
                    colorD = sensorD.hsv()

                    if selected == "branco":
                        print("branco :", colorE, "preto :", colorD)
                        array_colors = array_colors[:12] + hsv_to_bytes(colorD) + hsv_to_bytes(colorE)
                    else:
                        start_index = menu_index * 4
                        array_colors = array_colors[:start_index] + hsv_to_bytes(colorD) + array_colors[start_index + 4:]
                        print(selected, ":", colorD)

            elif Button.LEFT in pressed:
                menu_index = (menu_index - 1) % len(menu_keys)
            elif Button.RIGHT in pressed:
                menu_index = (menu_index + 1) % len(menu_keys)

            selected = menu_keys[menu_index]
            hub.light.on(colors_copy[selected])


def ComparaHsv(hsv, color_name, sens=20):
    color = colors[color_name]
    hresult = abs(hsv.h - color.h) <= sens
    sresult = abs(hsv.s - color.s) <= sens
    vresult = abs(hsv.v - color.v) <= sens
    return hresult and sresult and vresult

def ChecaVerde():
    eColor = sensorE.hsv()
    dColor = sensorD.hsv()
    pitch = hub.imu.tilt()[0]
    if ComparaHsv(eColor, "green") or ComparaHsv(dColor, "green") and -5 < pitch < 5:
        print("verde")
        hub.speaker.beep(1000, 200)
        drive.stop()
        wait(500)
        drive.drive(forcaBase - 10, 0)
        # Verde ESQUERDA
        if ComparaHsv(eColor, "green"):
            print("esquerda")
            while True:
                # Se viu verde no outro sensor (verde verde)
                if ComparaHsv(sensorD.hsv(), "green"):
                    print("verde verde")
                    VerdeVerde()
                    break
                if sensorE.hsv().h > 175:
                    if sensorE.hsv().v > 50:
                        print("branco")
                        break
                    elif sensorE.hsv().v <= 50:
                        Send("OCUPADO", 1)
                        SendBLE()
                        print("preto")
                        drive.straight(40)
                        drive.turn(30)
                        GiraAtePreto(120, 150, sensorE)
                        drive.turn(15)
                        wait(10)
                        break
                wait(10)
        # Verde DIREITA
        elif ComparaHsv(dColor, "green"):
            print("direita")
            while True:
                # Se viu verde no outro sensor (verde verde)
                if ComparaHsv(sensorE.hsv(), "green"):
                    VerdeVerde()
                    break
                if sensorD.hsv().h > 175:
                    if sensorD.hsv().v > 50:
                        print("branco")
                        break
                    elif sensorD.hsv().v <= 50:
                        Send("OCUPADO", 1)
                        SendBLE()
                        print("preto")
                        drive.straight(40)
                        drive.turn(-30)
                        GiraAtePreto(-120, 150, sensorD)
                        drive.turn(-15)
                        wait(10)
                        break
                wait(10)

def VerdeVerde():
    print("beco")
    while True:
        if sensorD.hsv().h > 175:
            if sensorD.hsv().v > 50:
                print("branco")
                break
            elif sensorD.hsv().v <= 50:
                Send("OCUPADO", 1)
                SendBLE()
                print("preto")
                drive.straight(30)
                drive.turn(-135)
                GiraAtePreto(-150, 150, sensorD)
                drive.turn(-15)
                wait(10)
                break
        wait(10)

def ChecaObstaculo(lado=1):
    pitch = hub.imu.tilt()[0]
    distancia = ultra.distance()
    print("pitch: ", pitch, "distancia: ", ultra.distance())
    if distancia < 50 and -5 < pitch < 5:
        drive.stop()
        drive.turn(-90 * lado)
        drive.straight(220)
        drive.turn(90 * lado)
        x = 3
        for _ in range(x):
            if MoveAtePreto(210, 210, 250, sensorE, sensorD):
                drive.straight(80)
                drive.turn(-45 * lado)
                if lado == 1:
                    GiraAtePreto(-150 * lado, 150, sensorD)
                else:
                    GiraAtePreto(-150 * lado, 150, sensorE)

                drive.turn(-20 * lado)
                drive.straight(-25)
                drive.stop()
                return
            else:
                drive.straight(200)
                drive.turn(97 * lado)

def Pid():
    global integral, last_error
    print("E: ", sensorE.reflection(), "D: ", sensorD.reflection())
    erro = sensorE.reflection() - sensorD.reflection()
    if abs(erro) < 10 and sensorD.reflection() > 50:
        erro = 0
    proporcional = erro * _KP
    integral += erro * _KI
    derivado = (erro - last_error) * _KD
    correcao = proporcional + integral + derivado
    motorE.run(forcaBase - correcao)
    motorD.run(forcaBase + correcao)
    last_error = erro

def MoveAtePreto(speed_left, speed_right, distance, sensorA, sensorB = None):
    motorE.reset_angle(0)
    motorD.reset_angle(0)

    target_angle = distance * (360 / (3.1416 * 36))

    while abs(motorE.angle()) < target_angle and abs(motorD.angle()) < target_angle:
        if sensorB == None:
            if sensorA.reflection() < 25:
                return True
        else:
            if sensorA.reflection() < 25 or sensorB.reflection() < 25:
                return True
        motorE.run(speed_left)
        motorD.run(speed_right)

    motorE.stop()
    motorD.stop()
    return False

def GiraAtePreto(speed, distance, sensorA, sensorB = None):
    motorE.reset_angle(0)
    motorD.reset_angle(0)

    target_angle = distance * (360 / (3.1416 * 36))

    while abs(motorE.angle()) < target_angle and abs(motorD.angle()) < target_angle:
        if sensorB == None:
            if sensorA.reflection() < 25:
                break
        else:
            if sensorA.reflection() < 25 or sensorB.reflection() < 25:
                break
        motorE.run(speed)
        motorD.run(-speed)

    hub.speaker.beep(900, 200)
    motorE.stop()
    motorD.stop()

def RetaInterrompida(speed_left, speed_right, distance, sens):
    motorE.reset_angle(0)
    motorD.reset_angle(0)

    target_angle = distance * (360 / (3.1416 * 36))

    while abs(motorE.angle()) < target_angle and abs(motorD.angle()) < target_angle:
        if abs(motorE.angle()) > 270:
            diferencaA = abs(abs(motorE.speed()) - abs(speed_left))
            diferencaB = abs(abs(motorD.speed()) - abs(speed_right))
            print("diferencaA: ", diferencaA, "diferencaB: ", diferencaB)
            if diferencaA > sens or diferencaB > sens:
                drive.stop()
                print("saiu")
                wait(1000)
                return True
        motorE.run(speed_left)
        motorD.run(speed_right)

    motorE.stop()
    motorD.stop()
    return False

def ChecaPrata():
    eColor = sensorE.hsv()
    dColor = sensorD.hsv()
    pitch = hub.imu.tilt()[0]
    if ComparaHsv(eColor, "prata") and ComparaHsv(dColor, "prata") and -5 < pitch < 5:
        print("prata")
        hub.speaker.beep(1000, 200)
        drive.stop()
        wait(500)
        Send("ESTADO", Estado.RESGATE)
        return True
    return False

def Resgate():
    Send("ULTRA", (ultra.distance() // 10))
    drive.straight(220)
    drive.turn(-90)
    wait(200)
    if ultra.distance() < 600:
        drive.straight(200)
        drive.straight(-50)
        drive.turn(90)
        Send("GARRA", Garra.ABERTA)
        SendBLE()
        RetaInterrompida(210, 210, 400, 80)
        hub.speaker.beep(1100, 200)
        drive.straight(-75)
        Send("GARRA", Garra.FECHADA)
        SendBLE()
        drive.straight(75)
        wait(200)
        GetBLE()
        print("Reflexo" ,Read("FRFX"))
        
    
    Send("ESTADO", Estado.PLAY)

def Seguidor():
    ChecaObstaculo(-1)
    ChecaVerde()
    if not ChecaPrata():
        Pid()

def Play():
    global integral, last_error
    integral = 0
    last_error = 0
    GetStoredColors(colors, colors_array)
    print(colors)

    Send("ESTADO", Estado.PLAY)

    WaitTheOtherHub()

    while True:
        # print(ultra.distance())
        # wait(500)
        GetBLE()

        if CheckStopButton() or Read("ESTADO") == Estado.MAIN:
            drive.stop()
            break

        if Send("ESTADO") == Estado.PLAY:
            Seguidor()
        elif Send("ESTADO") == Estado.RESGATE:
            Resgate()

        SendBLE()
        wait(10)

if __name__ == "__main__":
    from Main import Start
    Start(1)