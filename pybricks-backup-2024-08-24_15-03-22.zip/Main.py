from pybricks.parameters import Button, Icon
from pybricks.tools import wait

# Importa tudo do "__all__" de ExtraTools
from ExtraTools import *
# Importa especificamente
# from ExtraTools import BlinkHubColor, SetHubColor

# Verifica qual robô é; de Cima ou de Baixo
if thisHub == Cima:
    from HadesCima import Play, AnotaCor
else:
    from HadesBaixo import Play, AnotaCor

Send("ESTADO", Estado.MAIN)

menu_options = {
    "Cor": 100,
    "Play": 0
}
menu_keys = list(menu_options.keys())
menu_index = 0

selected = menu_keys[menu_index]
BlinkHubColor(menu_options[selected])

hub.display.icon(Icon.FULL)

def SelectProgram(program):

    while CheckStopButton():
        wait(10)

    hub.display.off()
    SetHubColor(menu_options[program], 50)
    if program == "Cor":
        AnotaCor()
    elif program == "Play":
        Play()

    hub.display.icon(Icon.FULL)
    selected = menu_keys[menu_index]
    BlinkHubColor(menu_options[selected])

    while CheckStopButton():
        wait(10)

    Send("ESTADO", Estado.MAIN)
    if Read("ESTADO") == Estado.MAIN:
        Send("WAITING", 0)
    else:
        Send("WAITING", 1)

def Start():
    global selected, menu_index, menu_keys, menu_options

    SeePorts()

    while CheckStopButton():
        wait(10)

    while True:
        result = GetButton()
        pressed = time_pressed = None

        if result is None:
            if Read("ESTADO") == Estado.PLAY:
                SelectProgram("Play")
            if Read("ESTADO") == Estado.COR:
                SelectProgram("Cor")

        if result is not None:
            pressed = result[0]
            if Button.CENTER in pressed:
                SelectProgram(selected)
            elif Button.LEFT in pressed:
                menu_index = (menu_index - 1) % len(menu_keys)
            elif Button.RIGHT in pressed:
                menu_index = (menu_index + 1) % len(menu_keys)

        selected = menu_keys[menu_index]
        BlinkHubColor(menu_options[selected])
        wait(5)

if __name__ == "__main__":
    Start()