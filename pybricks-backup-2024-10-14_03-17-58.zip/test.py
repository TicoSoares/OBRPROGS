from pybricks.hubs import PrimeHub
from pybricks.parameters import Axis
from pybricks.tools import wait

hub = PrimeHub()

# Função para obter a média das leituras do giroscópio
def leitura_media_gyro(sensor_func, n=5):
    leituras = [sensor_func() for _ in range(n)]
    return sum(leituras) / len(leituras)

# Função para verificar se o pitch está inclinado por um certo tempo com histerese
def detectar_inclinacao(pitch_limite, pitch_histerese, tempo_limite=200):
    tempo_inclinado = 0
    inclinado = False

    while tempo_inclinado < tempo_limite:
        # Média do pitch e da velocidade angular no eixo Z
        pitch_medio = leitura_media_gyro(lambda: hub.imu.tilt()[0])
        velocidade_z_media = leitura_media_gyro(lambda: hub.imu.angular_velocity(Axis.Z), n=3)
        
        # Se o pitch estiver acima do limite e o robô não estiver girando rápido
        if pitch_medio > pitch_limite:
            inclinado = True
            tempo_inclinado += 10  # Contando 10ms por iteração
        elif pitch_medio < pitch_histerese:  # Aplicar histerese ao parar a detecção
            inclinado = False
            tempo_inclinado = 0  # Reiniciar contagem se a condição não for satisfeita

        wait(10)  # Aguardar 10ms antes de medir novamente

    return inclinado
contador = 0
while True:
    # Verificar se o pitch está acima do limite com histerese
    if detectar_inclinacao(15, 10):  # 20 como limite, 15 como histerese
        contador += 1
        print("Inclinação detectada! ", contador)  # Aguardar 100ms antes 
