from pybricks.pupdevices import Motor, ColorSensor
from pybricks.parameters import Port, Direction, Color
from pybricks.tools import wait
from pybricks.robotics import DriveBase
from pybricks.hubs import PrimeHub

from ExtraTools import *

hub = PrimeHub()

# Motores e sensores
sensorE = ColorSensor(Port.C)
sensorM = ColorSensor(Port.F)
sensorD = ColorSensor(Port.A)
motorE = Motor(Port.D)
motorD = Motor(Port.B, Direction.COUNTERCLOCKWISE)
drive = DriveBase(motorE, motorD, 30.9, 137.5)
drive.settings()
default_settings = drive.settings()
drive.settings(539.9999, 5393.99, 100)
fast_settings = drive.settings()
drive.use_gyro(True)

# Constantes do PID
kp, ki, kd = 8, 0.0, 1

# Variáveis do PID para ambos os lados
erro_anterior = {'esq': 0, 'dir': 0}
integral = {'esq': 0, 'dir': 0}

colors = {
    "green": Color.GREEN,
    "prata": Color.VIOLET,
    "red": Color.RED,
    "preto": Color.BLACK,
    "branco": Color.WHITE
}
colors_copy = colors.copy()
colors_array = ["green", "prata", "red", "branco"]

forcaBase = 500
vel_virada = 400

timer_branco = StopWatch()

def ComparaHsv(hsv, color_name, sens=20):
    color = colors[color_name]
    hresult = abs(hsv.h - color.h) <= sens
    sresult = abs(hsv.s - color.s) <= sens
    vresult = abs(hsv.v - color.v) <= sens
    return hresult and sresult and vresult

GetStoredColors(colors, colors_array)

def MoveAteCor(speed_left, speed_right, distance, sensorA, sensorB = None, sensorC = None, cor = "preto", tolerance=20):
    global preto_max, preto_min
    motorE.reset_angle(0)
    motorD.reset_angle(0)

    target_angle = distance * (360 / (3.1416 * 30.9))

    while abs(motorE.angle()) < target_angle and abs(motorD.angle()) < target_angle:
        if sensorB == None:
            if ComparaHsv(sensorA.hsv(), cor, tolerance):
                return True
        elif sensorC == None:
            if ComparaHsv(sensorA.hsv(), cor, tolerance) or ComparaHsv(sensorB.hsv(), cor, tolerance):
                return True
        else:
            if ComparaHsv(sensorA.hsv(), cor, tolerance) or ComparaHsv(sensorB.hsv(), cor, tolerance) or ComparaHsv(sensorC.hsv(), cor, tolerance):
                return True
        motorE.run(speed_left)
        motorD.run(speed_right)

    motorE.stop()
    motorD.stop()
    return False

def calcular_erro(sensor_lateral, sensorM):
    # Calcular o erro entre o sensor lateral e o central
    erro = (70 - sensor_lateral.reflection()) - (12 - sensorM.reflection())
    return erro

def pid_control(erro, lado):
    # Controle PID manual
    proporcional = erro * kp
    integral[lado] += erro
    i = integral[lado] * ki
    derivativo = (erro - erro_anterior[lado]) * kd
    erro_anterior[lado] = erro
    return proporcional + i + derivativo

def Seguidor():
    global forcaBase
    sensorA = sensorD
    sensorB = sensorE
    lado_preto = 1
    corE = sensorE.hsv()
    corM = sensorM.hsv()
    corD = sensorD.hsv()
    print(f"timer: {timer_branco.time()}")
    if ComparaHsv(corE, "branco", 15) and ComparaHsv(corM, "branco", 15) and ComparaHsv(corD, "branco", 15): 
        timer_branco.resume()
        if timer_branco.time() > 2000:
            forcaRe = forcaBase + 150
            MoveAteCor(-forcaRe, -forcaRe, 5000, sensorE, sensorM, sensorD, "preto")
            drive.straight(-50)
            forcaDefault = forcaBase
            forcaBase = 100
            x = 3000
            for _ in range(x):
                Pid()
            
            forcaBase = forcaDefault
            timer_branco.reset()
    else:
        timer_branco.reset()
        timer_branco.pause()
    if not ComparaHsv(corM, "branco", 5):
        if ComparaHsv(corD, "preto", 12) and ComparaHsv(corE, "branco", 15) or ComparaHsv(corE, "preto", 12) and ComparaHsv(corD, "branco", 15):
            if ComparaHsv(corE, "preto", 12):
                sensorA = sensorE
                sensorB = sensorD
                lado_preto = -1
            drive.straight(30)
            giro = MoveAteCor(vel_virada * lado_preto, -vel_virada * lado_preto, 190, sensorB, cor="preto")
            if not giro:
                MoveAteCor(-vel_virada * lado_preto, vel_virada * lado_preto, 500, sensorA, cor="preto")
                MoveAteCor(vel_virada * lado_preto, -vel_virada * lado_preto, 500, sensorA, cor="branco", tolerance=7)
                drive.straight(-10)
                return
            MoveAteCor(-vel_virada * lado_preto, vel_virada * lado_preto, 500, sensorB, cor="branco", tolerance=7)
            drive.turn(-5 * lado_preto)
            drive.straight(-10)
    Pid()

def Pid():
    # Calcular erros para cada lado
    erro_esq = calcular_erro(sensorE, sensorM)
    erro_dir = calcular_erro(sensorD, sensorM)
    if ComparaHsv(sensorE.hsv(), "branco", 15) and ComparaHsv(sensorM.hsv(), "branco", 15) and ComparaHsv(sensorD.hsv(), "branco", 15): 
        erro_esq, erro_dir = 0, 0

    # Obter correções PID para cada lado
    correcao_esq = pid_control(erro_esq, 'esq')
    correcao_dir = pid_control(erro_dir, 'dir')

    # Calcular a velocidade de cada motor individualmente
    correcaoGeral = correcao_esq - correcao_dir
    velocidade_motorE = forcaBase - correcaoGeral
    velocidade_motorD = forcaBase + correcaoGeral
    velocidade_motorE = max(min(velocidade_motorE, forcaBase), -forcaBase)
    velocidade_motorD = max(min(velocidade_motorD, forcaBase), -forcaBase)
    #print(f"{correcao_esq} {correcao_dir} | {correcao_esq - correcao_dir}")
    motorE.run(velocidade_motorE)
    motorD.run(velocidade_motorD)


while True:
    Seguidor()
    wait(5)
