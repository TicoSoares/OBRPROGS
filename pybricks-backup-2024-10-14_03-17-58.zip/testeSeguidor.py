from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor, ForceSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch

from ExtraTools import *

hub = PrimeHub()

sensorD = ColorSensor(Port.A)
sensorM = ColorSensor(Port.F)
sensorE = ColorSensor(Port.C)
ultraF = UltrasonicSensor(Port.E)
motorD = Motor(Port.B, Direction.COUNTERCLOCKWISE)
motorE = Motor(Port.D)
drive = DriveBase(motorE, motorD, 30.9, 137.5)
drive.settings()
default_settings = drive.settings()
drive.settings(539.9999, 5393.99, 100)
fast_settings = drive.settings()
drive.use_gyro(True)

colors = {
    "green": Color.GREEN,
    "prata": Color.VIOLET,
    "red": Color.RED,
    "preto": Color.BLACK,
    "branco": Color.WHITE
}
colors_copy = colors.copy()
colors_array = ["green", "prata", "red", "branco"]

pid_erro = 0
integral = 0
last_error = 0

vermelho = False

erro_vel_factor = 0
forcaBase = 500
vel_virada = 400
_KP = 11
_KI = 0.0
_KD = 7

def ComparaHsv(hsv, color_name, sens=20):
    color = colors[color_name]
    hresult = abs(hsv.h - color.h) <= sens
    sresult = abs(hsv.s - color.s) <= sens
    vresult = abs(hsv.v - color.v) <= sens
    return hresult and sresult and vresult

GetStoredColors(colors, colors_array)

def MoveAteCor(speed_left, speed_right, distance, sensorA, sensorB = None, cor = "preto", tolerance=20):
    global preto_max, preto_min
    motorE.reset_angle(0)
    motorD.reset_angle(0)

    target_angle = distance * (360 / (3.1416 * 30.9))

    while abs(motorE.angle()) < target_angle and abs(motorD.angle()) < target_angle:
        if sensorB == None:
            if ComparaHsv(sensorA.hsv(), cor, tolerance):
                return True
        else:
            if ComparaHsv(sensorA.hsv(), cor, tolerance) or ComparaHsv(sensorB.hsv(), cor, tolerance):
                return True
        motorE.run(speed_left)
        motorD.run(speed_right)

    motorE.stop()
    motorD.stop()
    return False

def PidA():
    global integral, last_error, pid_erro, preto_max, preto_min
    sensorA = sensorD
    sensorB = sensorE
    lado_preto = 1
    corE = sensorE.hsv()
    corD = sensorD.hsv()
    if ComparaHsv(corD, "preto", 12) and ComparaHsv(corE, "branco", 15) or ComparaHsv(corE, "preto", 12) and ComparaHsv(corD, "branco", 15):
        if ComparaHsv(corE, "preto", 12):
            sensorA = sensorE
            sensorB = sensorD
            lado_preto = -1
        drive.straight(30)
        giro = MoveAteCor(vel_virada * lado_preto, -vel_virada * lado_preto, 190, sensorM, cor="preto")
        if not giro:
            MoveAteCor(-vel_virada * lado_preto, vel_virada * lado_preto, 500, sensorM, cor="preto")
            drive.straight(-10)
            return
        drive.straight(-10)
    else:
        pid_erro = sensorD.reflection() - sensorE.reflection()
        if ComparaHsv(sensorE.hsv(), "branco") and ComparaHsv(sensorD.hsv(), "branco"):
            pid_erro = 0
        proporcional = pid_erro * _KP
        integral += pid_erro * _KI
        derivado = (pid_erro - last_error) * _KD
        correcao = proporcional + integral + derivado
        negativeForce = abs(pid_erro) * erro_vel_factor
        motorE.run((forcaBase - negativeForce) - correcao)
        motorD.run((forcaBase - negativeForce) + correcao)
        last_error = pid_erro

def PidB():
    global integral, last_error, pid_erro
    pid_erro = sensorD.reflection() - sensorE.reflection()
    if ComparaHsv(sensorE.hsv(), "branco") and ComparaHsv(sensorD.hsv(), "branco"):
        pid_erro = 0
    proporcional = pid_erro * _KP
    integral += pid_erro * _KI
    derivado = (pid_erro - last_error) * _KD
    correcao = proporcional + integral + derivado
    negativeForce = abs(pid_erro) * erro_vel_factor
    motorE.run((forcaBase - negativeForce) - correcao)
    motorD.run((forcaBase - negativeForce) + correcao)
    last_error = pid_erro

while True:
    #print(f"{sensorE.reflection()} {sensorM.reflection()} {sensorD.reflection()}")
    print(70 - sensorE.reflection())