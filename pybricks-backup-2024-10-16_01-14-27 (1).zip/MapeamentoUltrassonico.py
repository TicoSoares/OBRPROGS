from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor, ForceSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch

hub = PrimeHub()

sensorD = ColorSensor(Port.A)
sensorE = ColorSensor(Port.C)
#ultraF = UltrasonicSensor(Port.E)
ultraT = UltrasonicSensor(Port.F)
motorD = Motor(Port.B, Direction.COUNTERCLOCKWISE)
motorE = Motor(Port.D)
drive = DriveBase(motorE, motorD, 30.9, 137.5)
drive.settings()
default_settings = drive.settings()
drive.settings(539.9999, 5393.99, 100)
fast_settings = drive.settings()
drive.use_gyro(True)

timer = StopWatch()
timer.pause()

# Função para girar o robô e coletar dados
def map_area(rotation_speed=200, total_rotation=180):
    timer.reset()
    timer.resume()
    hub.imu.reset_heading(0)
    data_line = ""
    while hub.imu.heading() < total_rotation:  # Gira até completar 360 graus
        # Captura o ângulo e as distâncias
        current_angle = hub.imu.heading()
        distance_front = 3000
        distance_back = ultraT.distance()

        data_line += f"{current_angle} {distance_front} {distance_back}_"

        # Espera um pouco antes da próxima leitura para não sobrecarregar
        motorE.run(rotation_speed * 1 if total_rotation > 0 else -1)
        motorD.run(rotation_speed * -1 if total_rotation > 0 else 1)
        wait(50)

    # Para o motor ao finalizar o mapeamento
    drive.stop()
    timer.pause()
    print(data_line)
    print("timer: ", timer.time())

# Executa o mapeamento
map_area(60, 360)
#while True:#
    #print(f"{ultraF.distance()} {ultraT.distance()}")