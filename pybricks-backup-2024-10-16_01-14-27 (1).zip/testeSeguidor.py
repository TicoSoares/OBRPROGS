from pybricks.pupdevices import Motor, ColorSensor
from pybricks.parameters import Port, Direction, Color
from pybricks.tools import wait
from pybricks.robotics import DriveBase
from pybricks.hubs import PrimeHub

from ExtraTools import *

hub = PrimeHub()

# Motores e sensores
sensorE = ColorSensor(Port.C)
sensorM = ColorSensor(Port.F)
sensorD = ColorSensor(Port.A)
motorE = Motor(Port.D)
motorD = Motor(Port.B, Direction.COUNTERCLOCKWISE)
drive = DriveBase(motorE, motorD, 30.9, 137.5)
drive.settings()
default_settings = drive.settings()
drive.settings(539.9999, 5393.99, 100)
fast_settings = drive.settings()
drive.use_gyro(True)

# Constantes do PID
kp, ki, kd = 8, 0.0, 1

vermelho = False

# Variáveis do PID para ambos os lados
erro_anterior = 0
integral = 0

colors = {
    "green": Color.GREEN,
    "prata": Color.VIOLET,
    "red": Color.RED,
    "preto": Color.BLACK,
    "branco": Color.WHITE
}
colors_copy = colors.copy()
colors_array = ["green", "prata", "red", "branco"]

forcaBase = 400
vel_virada = 400

timer_branco = StopWatch()

def AnotaCor():
    hub.system.set_stop_button([Button.LEFT, Button.CENTER])
    global colors_note

    Send("ESTADO", Estado.COR)
    hub.display.off()

    menu_keys = colors_array
    menu_index = 0

    selected = menu_keys[menu_index]
    hub.light.on(colors_copy[selected])

    array_colors = hub.system.storage(0, read=20) 

    while True:
        result = GetButton()
        pressed = time_pressed = None
        if result is None:
            break
        else:
            pressed, time_pressed = result
            if Button.CENTER in pressed:
                if time_pressed > 500:
                    break
                else:
                    colorE = sensorE.hsv()
                    colorD = sensorD.hsv()

                    if selected == "branco":
                        print("branco :", colorE, "preto :", colorD)
                        array_colors = array_colors[:12] + hsv_to_bytes(colorD) + hsv_to_bytes(colorE)
                    else:
                        start_index = menu_index * 4
                        array_colors = array_colors[:start_index] + hsv_to_bytes(colorD) + array_colors[start_index + 4:]
                        print(selected, ":", colorD)

                    hub.system.storage(0, write=array_colors)
                    print(hub.system.storage(0, read=20))

            elif Button.LEFT in pressed:
                menu_index = (menu_index - 1) % len(menu_keys)
            elif Button.RIGHT in pressed:
                menu_index = (menu_index + 1) % len(menu_keys)

            selected = menu_keys[menu_index]
            hub.light.on(colors_copy[selected])


def ComparaHsv(hsv, color_name, sens=20):
    color = colors[color_name]
    hresult = abs(hsv.h - color.h) <= sens
    sresult = abs(hsv.s - color.s) <= sens
    vresult = abs(hsv.v - color.v) <= sens
    return hresult and sresult and vresult

GetStoredColors(colors, colors_array)

def MoveAteCor(speed_left, speed_right, distance, sensorA, sensorB = None, sensorC = None, cor = "preto", tolerance=20):
    global preto_max, preto_min
    motorE.reset_angle(0)
    motorD.reset_angle(0)

    target_angle = distance * (360 / (3.1416 * 30.9))

    while abs(motorE.angle()) < target_angle and abs(motorD.angle()) < target_angle:
        if sensorB == None:
            if ComparaHsv(sensorA.hsv(), cor, tolerance):
                return True
        elif sensorC == None:
            if ComparaHsv(sensorA.hsv(), cor, tolerance) or ComparaHsv(sensorB.hsv(), cor, tolerance):
                return True
        else:
            if ComparaHsv(sensorA.hsv(), cor, tolerance) or ComparaHsv(sensorB.hsv(), cor, tolerance) or ComparaHsv(sensorC.hsv(), cor, tolerance):
                return True
        motorE.run(speed_left)
        motorD.run(speed_right)

    motorE.stop()
    motorD.stop()
    return False

def ChecaCores():
    eColor = sensorE.hsv()
    mColor = sensorM.hsv()
    dColor = sensorD.hsv()
    pitch = hub.imu.tilt()[0]

    if (ComparaHsv(eColor, "green") or ComparaHsv(dColor, "green") or ComparaHsv(mColor, "green")) and -5 < pitch < 5:
        sensorA = sensorD
        sensorB = sensorE
        lado_verde = -1
        print("verde")
        hub.speaker.beep(1000, 200)
        drive.stop()
        if ComparaHsv(mColor, "green") and not (ComparaHsv(eColor, "green") or ComparaHsv(dColor, "green")):
            drive.straight(-75)
            return
        wait(500)
        drive.drive(60, 0)
        if ComparaHsv(eColor, "green") and ComparaHsv(dColor, "green"):
            print("verde BECO")
            VerdeVerde()
        elif ComparaHsv(eColor, "green"):
            sensorA = sensorE
            sensorB = sensorD
            lado_verde = 1
        
        drive.turn(15 * lado_verde)
        drive.straight(-15)
        drive.drive(60, 0)
        while True:
            # Verifica dnv se é verde verde caso tenha passado e n viu
            if ComparaHsv(sensorB.hsv(), "green"):
                print("verde verde")
                VerdeVerde()
                break
            if not ComparaHsv(sensorA.hsv(), "green"):
                if ComparaHsv(sensorA.hsv(), "branco", 10):
                    drive.turn(-25*lado_verde)
                    print("branco")
                    break
                elif ComparaHsv(sensorA.hsv(), "preto", 15):
                    Send("OCUPADO", 1)
                    SendBLE()
                    print("preto")
                    drive.straight(55)
                    drive.turn(-30 * lado_verde)
                    MoveAteCor(-500 * lado_verde, 500 * lado_verde, 150, sensorA)
                    drive.turn(-30 * lado_verde)
                    drive.straight(40)
                    break
    
    elif ComparaHsv(eColor, "red") and ComparaHsv(dColor, "red") and -5 < pitch < 5:
        hub.speaker.beep(850, 200)
        vermelho = True
        return True

    elif ComparaHsv(eColor, "prata", 5) and ComparaHsv(dColor, "prata", 5) and -5 < pitch < 5:
        print("prata")
        drive.stop()
        hub.speaker.beep(1000, 100)
        giro = MoveAteCor(-250,250, 60, sensorD)
        wait(100)
        if not giro == "Preto":
            drive.turn(35)
            Send("ESTADO", Estado.RESGATE)
            return True
        hub.speaker.beep(1000, 100)
        drive.turn(40)

    return False

def VerdeVerde():
    print("beco")
    while True:
        if not ComparaHsv(sensorD.hsv(), "green"):
            if ComparaHsv(sensorD.hsv(), "branco", 5):
                print("branco")
                break
            elif ComparaHsv(sensorD.hsv(), "preto", 25):
                Send("OCUPADO", 1)
                SendBLE()
                print("preto")
                drive.straight(30)
                drive.turn(180)
                drive.straight(20)
                break

def pid_control(erro):
    global integral, erro_anterior
    # Controle PID manual
    proporcional = erro * kp
    integral += erro
    i = integral * ki
    derivativo = (erro - erro_anterior) * kd
    erro_anterior = erro
    return proporcional + i + derivativo

def Seguidor():
    global forcaBase
    sensorA = sensorD
    sensorB = sensorE
    lado_preto = 1
    corE = sensorE.hsv()
    corM = sensorM.hsv()
    corD = sensorD.hsv()
    print(f"timer: {timer_branco.time()}")
    if ComparaHsv(corE, "branco", 15) and ComparaHsv(corM, "branco", 15) and ComparaHsv(corD, "branco", 15): 
        timer_branco.resume()
        if timer_branco.time() > 1500:
            forcaRe = forcaBase - 200
            MoveAteCor(-forcaRe, -forcaRe, 5000, sensorE, sensorM, sensorD, "preto")
            drive.straight(-40)
            forcaDefault = forcaBase
            forcaBase = 100
            x = 2000
            for _ in range(x):
                Pid()
            
            forcaBase = forcaDefault
            timer_branco.reset()
    else:
        timer_branco.reset()
        timer_branco.pause()
    if not ComparaHsv(corM, "branco", 5):
        if ComparaHsv(corD, "preto", 12) and ComparaHsv(corE, "branco", 15) or ComparaHsv(corE, "preto", 12) and ComparaHsv(corD, "branco", 15):
            if ComparaHsv(corE, "preto", 12):
                sensorA = sensorE
                sensorB = sensorD
                lado_preto = -1
            drive.straight(45)
            if ComparaHsv(sensorE.hsv(), "green") or ComparaHsv(sensorD.hsv(), "green"):
                drive.straight(30)
                return
            giro = MoveAteCor(vel_virada * lado_preto, -vel_virada * lado_preto, 160, sensorB, cor="preto")
            if not giro:
                MoveAteCor(-vel_virada * lado_preto, vel_virada * lado_preto, 500, sensorA, cor="preto")
                MoveAteCor(vel_virada * lado_preto, -vel_virada * lado_preto, 500, sensorA, cor="branco", tolerance=7)
                drive.straight(-10)
                return
            MoveAteCor(-vel_virada * lado_preto, vel_virada * lado_preto, 500, sensorB, cor="branco", tolerance=7)
            drive.turn(-5 * lado_preto)
            drive.straight(-10)
    Pid()

def Pid():
    # Calcular erros para cada lado
    erro = sensorD.reflection() - sensorE.reflection()
    if ComparaHsv(sensorE.hsv(), "branco", 15) and ComparaHsv(sensorM.hsv(), "branco", 15) and ComparaHsv(sensorD.hsv(), "branco", 15): 
        erro = 0

    # Obter correções PID para cada lado
    correcao = pid_control(erro)

    # Calcular a velocidade de cada motor individualmente
    velocidade_motorE = forcaBase - correcao
    velocidade_motorD = forcaBase + correcao
    velocidade_motorE = max(min(velocidade_motorE, forcaBase), -forcaBase)
    velocidade_motorD = max(min(velocidade_motorD, forcaBase), -forcaBase)
    #print(f"{correcao_esq} {correcao_dir} | {correcao_esq - correcao_dir}")
    motorE.run(velocidade_motorE)
    motorD.run(velocidade_motorD)

if CheckSideButton():
    AnotaCor()

hub.system.set_stop_button([Button.CENTER])
while True:
    if not ChecaCores():
        Seguidor()
    wait(5)
