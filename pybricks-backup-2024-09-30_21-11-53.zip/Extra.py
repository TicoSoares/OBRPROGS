from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor, ForceSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch

hub = PrimeHub()

motorE = Motor(Port.A, Direction.COUNTERCLOCKWISE)
motorD = Motor(Port.E)
sensorE = ColorSensor(Port.B)
sensorD = ColorSensor(Port.C)

colors = {
    "verde": Color.GREEN,
    "cinza": Color.GRAY,
    "vermelho": Color.RED,
    "preto": Color.BLACK,
    "branco": Color.WHITE
}
colors_copy = colors.copy()
colors_array = ["verde", "cinza", "vermelho", "preto", "branco"]

def SetHubColor(h, v=100):
    new_color = Color(h, 100, v)
    hub.light.on(new_color)

def BlinkHubColor(h, v=100):
    new_color = Color(h, 100, v)
    hub.light.blink(new_color, [250, 250])

def hsv_to_bytes(hsv):
    # Ajustar o valor de Hue para caber em 2 bytes (0-65535)
    h_int = int(hsv.h / 360 * 65535)
    h_bytes = h_int.to_bytes(2, 'big')

    # Saturation e Value já estão entre 0 e 100, ajustar para caber em 1 byte (0-255)
    s_byte = int(hsv.s / 100 * 255).to_bytes(1, 'big')
    v_byte = int(hsv.v / 100 * 255).to_bytes(1, 'big')

    return h_bytes + s_byte + v_byte

def bytes_to_hsv(hsv_bytes):
    # Lê os 2 primeiros bytes como Hue (0-65535) e converte para 0-360
    h = int.from_bytes(hsv_bytes[0:2], 'big') * 360 / 65535

    # Lê o próximo byte como Saturation (0-255) e converte para 0-100
    s = int.from_bytes(hsv_bytes[2:3], 'big') * 100 / 255

    # Lê o último byte como Value (0-255) e converte para 0-100
    v = int.from_bytes(hsv_bytes[3:4], 'big') * 100 / 255

    # Retorna como uma tupla (h, s, v)
    return Color(h,s,v)

def GetStoredColors(colors, colors_array):
    # Inicializa o bytearray com os dados armazenados na memória
    byte_data = hub.system.storage(0, read=len(colors_array) * 4)

    def bytes_to_color(start_index):
        """Converte os bytes armazenados em um objeto Color."""
        hsv_bytes = byte_data[start_index:start_index + 4]
        hsv = bytes_to_hsv(hsv_bytes)
        return hsv

    index = 0
    while index < len(colors_array):
        key = colors_array[index]
        start_index = index * 4

        if start_index + 4 <= len(byte_data):
            colors[key] = bytes_to_color(start_index)
        else:
            colors[key] = Color.BLACK
        index += 1

    print(colors)

def ComparaHsv(hsv, color_name, sens=20):
    color = colors[color_name]
    hresult = abs(hsv.h - color.h) <= sens
    sresult = abs(hsv.s - color.s) <= sens
    vresult = abs(hsv.v - color.v) <= sens
    return hresult and sresult and vresult

def GetButton():
    pressed = ()
    while not pressed:
        pressed = hub.buttons.pressed()
        wait(10)
    timer.reset()
    timer.resume()

    while hub.buttons.pressed():
        wait(10)
    timer.pause()

    return pressed, timer.time()

def CheckStopButton():
    return Button.CENTER in hub.buttons.pressed()

def CheckAnyButton():
    return Button.CENTER in hub.buttons.pressed() or Button.LEFT in hub.buttons.pressed() or Button.RIGHT in hub.buttons.pressed()

def AnotaCor():
    global colors_note

    menu_keys = colors_array
    menu_index = 0

    selected = menu_keys[menu_index]
    hub.light.on(colors_copy[selected])

    array_colors = hub.system.storage(0, read=len(colors_array) * 4) 

    while True:
        result = GetButton()
        pressed = time_pressed = None
        if result is None:
            break
        else:
            pressed, time_pressed = result

        if result is not None:
            pressed, time_pressed = result
            if Button.CENTER in pressed:
                if time_pressed > 1000:
                    print(hub.system.storage(0, read=20))
                    break
                else:
                    colorE = sensorE.hsv()
                    colorD = sensorD.hsv()

                    start_index = menu_index * 4
                    array_colors = array_colors[:start_index] + hsv_to_bytes(colorD) + array_colors[start_index + 4:]
                    hub.system.storage(0, write=array_colors)
                    print(selected, ":", colorD)

            elif Button.LEFT in pressed:
                menu_index = (menu_index - 1) % len(menu_keys)
            elif Button.RIGHT in pressed:
                menu_index = (menu_index + 1) % len(menu_keys)

            selected = menu_keys[menu_index]
            hub.light.on(colors_copy[selected])
