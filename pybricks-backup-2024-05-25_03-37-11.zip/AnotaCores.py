from pybricks.hubs import PrimeHub
from pybricks.pupdevices import ColorSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.tools import wait, StopWatch

hub = PrimeHub()

hub.light.on(Color(100, 100, 50))

def AnotaCor():
    while True:
        if Button.LEFT in botaoPress:
            cores[0] = sensorB.hsv()
            print("Verde: " + str(cores[0]))
        elif Button.RIGHT in botaoPress:
            cores[1] = sensorB.hsv()
            print("Prata: " + str(cores[1]))
        elif Button.CENTER in botaoPress:
            estado = 0
            botaoPress = []
            return