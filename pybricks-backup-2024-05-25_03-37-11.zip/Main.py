from pybricks.hubs import PrimeHub
from pybricks.parameters import Button, Color, Port
from pybricks.tools import wait

hub = PrimeHub()

import AnotaCores, Seguidor

menu_options = (1, 2)
menu_index = 0
selected = 1

hub.system.set_stop_button(None)

while True:

    # Wait for any button.
    pressed = ()
    while not pressed:
        pressed = hub.buttons.pressed()
        wait(10)

    # Wait for the button to be released.
    while hub.buttons.pressed():
        wait(10)

    # Now check which button was pressed.
    if Button.CENTER in pressed:
        SelectProgram(selected)
    elif Button.LEFT in pressed:
        # Left button, so decrement menu menu_index.
        menu_index = (menu_index + 1) % len(menu_options)
    elif Button.RIGHT in pressed:
        # Right button, so increment menu menu_index.
        menu_index = (menu_index - 1) % len(menu_options)

    selected = menu_options[menu_index]


def SelectProgram(index)
    if index == 1:
        AnotaCores()
    elif index == 2:
        Seguidor()