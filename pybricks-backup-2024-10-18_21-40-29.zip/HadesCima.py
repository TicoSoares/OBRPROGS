from pybricks.pupdevices import Motor, ColorSensor
from pybricks.parameters import Button, Color, Port, Axis
from pybricks.tools import wait

from ExtraTools import *

motorGarra = Motor(Port.E)
motorPorta = Motor(Port.A)
sensorF = ColorSensor(Port.B)

hub.system.set_stop_button([Button.LEFT, Button.CENTER])

colors = {
    "green": Color.GREEN,
    "red": Color.RED
}
colors_copy = colors.copy()
colors_array = ["green", "red"]

def AnotaCor():
    global colors_copy

    Send("ESTADO", Estado.COR)
    hub.display.off()

    menu_keys = colors_array
    menu_index = 0

    selected = menu_keys[menu_index]
    hub.light.on(colors_copy[selected])

    array_colors = hub.system.storage(0, read=8)  # Inicializa o bytearray com tamanho 20

    while True:
        result = GetButton()
        pressed = time_pressed = None
        if result is None:
            break
        else:
            pressed, time_pressed = result
            if Button.CENTER in pressed:
                if time_pressed > 1000:
                    break
                else:
                    colorF = sensorF.hsv()

                    start_index = menu_index * 4
                    array_colors = array_colors[:start_index] + hsv_to_bytes(colorF) + array_colors[start_index + 4:]
                    print(selected, ":", colorF)
                
                hub.system.storage(0, write=array_colors)
                print(hub.system.storage(0, read=8))

            elif Button.LEFT in pressed:
                menu_index = (menu_index - 1) % len(menu_keys)
            elif Button.RIGHT in pressed:
                menu_index = (menu_index + 1) % len(menu_keys)

            selected = menu_keys[menu_index]
            hub.light.on(colors_copy[selected])

def ComparaHsv(hsv, color_name, sens=30):
    color = colors[color_name]
    hresult = abs(hsv.h - color.h) <= sens
    sresult = abs(hsv.s - color.s) <= sens
    vresult = abs(hsv.v - color.v) <= sens
    return hresult and sresult and vresult

def SetGarra(garraState, motorSpeed=300):
    target_angles = {2: -183, 3: -255}
    target_angle = target_angles.get(garraState, 0)
    diferenca = abs(motorGarra.angle()) - abs(target_angle)
    if abs(diferenca) < 5:
        return
    motorGarra.run_target(motorSpeed, target_angle)

def SetPorta(portaState, motorSpeed=300):
    target_angles = {2: 135}
    target_angle = target_angles.get(portaState, 0)
    diferenca = abs(motorPorta.angle()) - abs(target_angle)
    print("motor: ", motorPorta.angle(), "target: ", target_angle)
    print("diferenca: ", abs(diferenca))
    if abs(diferenca) < 5:
        return
    motorPorta.run_target(motorSpeed, target_angle)

inclinado = False  # Flag de inclinação
tempo_inclinado = StopWatch()  # Cronômetro para medir tempo de inclinação
intervalo_leitura = StopWatch()  # Cronômetro para espaçar leituras

# Função para leitura média não bloqueante
def leitura_media_gyro(sensor_func, n=3):
    return sum(sensor_func() for _ in range(n)) / n

# Função otimizada para inclinação positiva e negativa separadamente
def detectar_inclinacao(pitch_limite, pitch_histerese, tempo_limite=200):
    global inclinado

    # Só lê o sensor a cada 50ms para evitar sobrecarga
    if intervalo_leitura.time() < 50:
        return

    # Reseta o cronômetro para a próxima leitura
    intervalo_leitura.reset()

    # Coleta os valores médios de pitch e velocidade angular no eixo Z
    pitch_medio = leitura_media_gyro(lambda: hub.imu.tilt()[0])
    velocidade_z_media = leitura_media_gyro(lambda: hub.imu.angular_velocity(Axis.Z))

    # Se o limite é positivo, detecta inclinação para frente
    if pitch_limite > 0:
        if pitch_medio > pitch_limite and abs(velocidade_z_media) < 10:
            if tempo_inclinado.time() >= tempo_limite:
                inclinado = True
        elif pitch_medio < pitch_histerese:  # Histerese para parar detecção positiva
            inclinado = False
            tempo_inclinado.reset()

    # Se o limite é negativo, detecta inclinação para trás
    elif pitch_limite < 0:
        if pitch_medio < pitch_limite and abs(velocidade_z_media) < 10:
            if tempo_inclinado.time() >= tempo_limite:
                inclinado = True
        elif pitch_medio > pitch_histerese:  # Histerese para parar detecção negativa
            inclinado = False
            tempo_inclinado.reset()

def Seguidor():
    GetBLE()
    detectar_inclinacao(10, 5)
    if inclinado:
        Send("GARRA", Garra.ABERTA)
    else:
        Send("GARRA", Garra.FECHADA)

    SetGarra(Send("GARRA"))

def Resgate():
    if ComparaHsv(sensorF.hsv(), "green"):
        Send("FCOR", 1)
        print("FCOR: ", "verde")
    elif ComparaHsv(sensorF.hsv(), "red"):
        Send("FCOR", 2)
        print("FCOR: ", "vermelho")
    else:
        Send("FCOR", 0)
        print("FCOR: ", "")
    
    SendBLE()
    
    GetBLE()
    Send("GARRA", Read("GARRA"))
    SetGarra(Send("GARRA"), 1000 if Read("GARRA") == Garra.ABERTA else 200)
    Send("PORTA", Read("PORTA"))
    SetPorta(Send("PORTA"), 3000)

def Play():

    Send("GARRA", Garra.FECHADA)
    Send("PORTA", Porta.FECHADA)
    Send("ESTADO", Estado.PLAY)

    motorGarra.reset_angle(0)
    motorPorta.reset_angle(0)
    GetStoredColors(colors, colors_array)
    print(colors)

    SetHubColor(0, 50)

    while True:
        data = GetBLE()

        if Read("ESTADO") == Estado.MAIN or not data:
            motorGarra.stop()
            motorPorta.stop()
            break

        if Read("ESTADO") == Estado.RESGATE:
            Send("ESTADO", Estado.RESGATE)

        if not Read("OCUPADO"):
            if Send("ESTADO") == Estado.PLAY:
                Seguidor()
            elif Send("ESTADO") == Estado.RESGATE:
                Resgate()

        SendBLE()
        wait(100)

if __name__ == "__main__":
    while True:
        Send("ESTADO", Estado.MAIN)
        BlinkHubColor(0)

        hub.system.set_stop_button([Button.CENTER])
        data = bytearray(0)

        while Read("ESTADO") == Send("ESTADO") or not data:
            data = GetBLE()
            motorGarra.stop()
            motorPorta.stop()
            wait(10)

        if Read("ESTADO") == Estado.COR:
            hub.system.set_stop_button([Button.LEFT, Button.CENTER])
            AnotaCor()
        elif Read("ESTADO") == Estado.PLAY:
            Play()
