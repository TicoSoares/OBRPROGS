from pybricks.hubs import PrimeHub
from pybricks.pupdevices import ColorSensor, UltrasonicSensor, ForceSensor, Motor
from pybricks.parameters import Port
from pybricks.iodevices import PUPDevice
from pybricks.tools import wait
from uerrno import ENODEV

hub = PrimeHub()

device_names = {
    48: "\033[96mMotor Medio\033[0m",  # Azul claro
    49: "\033[94mMotor Grande\033[0m",  # Azul escuro
    61: "\033[92mSensor de Cor\033[0m",         # Verde
    62: "\033[95mSensor Ultrassonico\033[0m",   # Roxo
    63: "\033[91mSensor de Toque\033[0m"        # Vermelho
}

ports = [Port.A, Port.B, Port.C, Port.D, Port.E, Port.F]

# Dicionário para armazenar as instâncias dos dispositivos
devices = {}

# Função para remover códigos ANSI de formatação (como cores e negrito)
def strip_ansi_codes(text):
    ansi_start = text.find("\033[")
    while ansi_start != -1:
        ansi_end = text.find("m", ansi_start) + 1
        text = text[:ansi_start] + text[ansi_end:]
        ansi_start = text.find("\033[")
    return text

# Função para inicializar os dispositivos conectados às portas
def initialize_devices():
    for port in ports:
        try:
            device = PUPDevice(port)
            id = device.info()["id"]
            if id in [48, 49]:  # Motores
                devices[port] = Motor(port)
            elif id == 61:
                devices[port] = ColorSensor(port)
            elif id == 62:
                devices[port] = UltrasonicSensor(port)
            elif id == 63:
                devices[port] = ForceSensor(port)
        except OSError as ex:
            if ex.args[0] == ENODEV:
                devices[port] = None  # Nenhum dispositivo conectado na porta
            else:
                raise ex

# Função para ver as portas e os dispositivos conectados
def SeePorts():
    port_info = []
    for port in ports:
        if devices.get(port) is None:
            port_info.append(f"\033[90m{port}: ---\033[0m")  # Cinza
        else:
            # Apenas utiliza o tipo já instanciado no dicionário 'devices'
            device = devices[port]
            if isinstance(device, Motor):
                port_info.append(f"\033[1m{port}: {device_names[48]}\033[0m")  # Motor Médio
            elif isinstance(device, ColorSensor):
                port_info.append(f"\033[1m{port}: {device_names[61]}\033[0m")  # Sensor de Cor
            elif isinstance(device, UltrasonicSensor):
                port_info.append(f"\033[1m{port}: {device_names[62]}\033[0m")  # Sensor Ultrassônico
            elif isinstance(device, ForceSensor):
                port_info.append(f"\033[1m{port}: {device_names[63]}\033[0m")  # Sensor de Toque
    return port_info

# Função para estimar a porcentagem de bateria
def get_battery_percentage():
    voltage = hub.battery.voltage() / 1000  # Converte de mV para V
    max_voltage = 8.4  # Bateria cheia
    min_voltage = 6.0  # Bateria quase descarregada
    battery_percentage = (voltage - min_voltage) / (max_voltage - min_voltage) * 100
    battery_percentage = max(0, min(100, battery_percentage))
    return battery_percentage

# Função para exibir uma barra de progresso da bateria
def get_battery_bar(percentage, bar_length=10):
    filled_length = int(bar_length * percentage // 100)
    bar = '#' * filled_length + '-' * (bar_length - filled_length)
    return f"\033[1m\033[93m[{bar}] {percentage:.2f}%\033[0m"  # Negrito e amarelo

# Função para pegar os dados do giroscópio
def get_gyro_data():
    pitch, roll = hub.imu.tilt()
    yaw = hub.imu.heading()
    return roll, pitch, yaw

# Função para obter os dados dos sensores e motores conectados
def get_sensor_data():
    sensor_data = []
    for port, device in devices.items():
        if device is None:
            continue
        try:
            if isinstance(device, ColorSensor):
                sensor_data.append(f"\033[1m\033[92m{port}: {device.reflection()}%\033[0m")  # Sensor de cor
            elif isinstance(device, UltrasonicSensor):
                sensor_data.append(f"\033[1m\033[95m{port}: {device.distance()} cm\033[0m")  # Sensor ultrassônico
            elif isinstance(device, Motor):
                sensor_data.append(f"\033[1m\033[96m{port}: {device.angle()} \033[0m")  # Ângulo do motor
            elif isinstance(device, ForceSensor):
                sensor_data.append(f"\033[1m\033[91m{port}: {device.force()} N\033[0m")  # Sensor de força
        except OSError:
            sensor_data.append(f"\033[91m{port}: Erro ao acessar\033[0m")
    return sensor_data

# Função para alinhar texto dinamicamente com base no comprimento sem formatação
def format_column(text, width):
    stripped_text = strip_ansi_codes(text)
    return text + ' ' * (width - len(stripped_text))

# Função para exibir as informações organizadas em colunas
def display_info():
    print("\x1b[H\x1b[2J", end="")

    ports_info = SeePorts()
    battery_percentage = get_battery_percentage()
    battery_bar = get_battery_bar(battery_percentage)
    roll, pitch, yaw = get_gyro_data()
    sensor_info = get_sensor_data()

    max_lines = max(len(ports_info), len(sensor_info), 4)

    output = []
    first_column_width = 29  # Largura ajustada para a primeira coluna
    second_column_width = 20  # Largura ajustada para a segunda coluna

    for i in range(max_lines):
        # Coluna da esquerda: dispositivos
        left = ports_info[i] if i < len(ports_info) else ""
        left = format_column(left, first_column_width)

        # Coluna do meio: giroscópio e barra de progresso
        middle = ""
        if i == 0:
            middle = f"\033[1m\033[96mRotacao: {roll}\033[0m"
        elif i == 1:
            middle = f"\033[1m\033[96mArfagem: {pitch}\033[0m"
        elif i == 2:
            middle = f"\033[1m\033[96mGuinada: {yaw:.2f}\033[0m"
        elif i == 3:
            middle = battery_bar
        middle = format_column(middle, second_column_width)

        # Coluna da direita: sensores
        right = sensor_info[i] if i < len(sensor_info) else ""
        right = format_column(right, first_column_width)

        # Adiciona a linha formatada ao buffer de saída
        output.append(f"{left} | {middle} | {right}")

    print("\n".join(output))

# Inicializa os dispositivos uma vez antes do loop principal
initialize_devices()

# Exibe as informações continuamente com maior taxa de atualização
while True:
    display_info()
    wait(500)
