from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor
from pybricks.parameters import Button, Color, Direction, Port
from pybricks.robotics import DriveBase
from pybricks.tools import wait, multitask, run_task

from ExtraTools import *

# Define as Portas
sensorD = ColorSensor(Port.A)
sensorE = ColorSensor(Port.B)
ultra = UltrasonicSensor(Port.D)
motorD = Motor(Port.C)
motorE = Motor(Port.E, Direction.COUNTERCLOCKWISE)

colors = {
    "green": Color.GREEN,
    "prata": Color.GRAY,
    "red": Color.RED,
    "preto": Color.BLACK,
    "branco": Color.WHITE
}
colors_copy = colors.copy()
colors_array = ["green", "prata", "red", "branco"]

integral = 0
last_error = 0

vermelho = False

forcaBase = 170
_KP = 9.0  # Este valor será ajustado para encontrar K_u
_KI = 0
_KD = 2.0

# Define motores de movimento
drive = DriveBase(motorE, motorD, wheel_diameter=40, axle_track=200)
# drive.settings(forcaBase, 120, 350, 210)
drive.settings(forcaBase)
defaultSettings = drive.settings()

def AnotaCor():
    global colors_note

    Send("ESTADO", Estado.COR)
    hub.display.off()

    menu_keys = colors_array
    menu_index = 0

    selected = menu_keys[menu_index]
    hub.light.on(colors_copy[selected])

    array_colors = hub.system.storage(0, read=20)  # Inicializa o bytearray com tamanho 20

    while True:
        result = GetButton()
        pressed = time_pressed = None
        if result is None:
            break
        else:
            pressed, time_pressed = result

        if result is not None:
            pressed, time_pressed = result
            if Button.CENTER in pressed:
                if time_pressed > 1000:
                    hub.system.storage(0, write=array_colors)
                    print(hub.system.storage(0, read=20))
                    break
                else:
                    colorE = sensorE.hsv()
                    colorD = sensorD.hsv()

                    if selected == "branco":
                        print("branco :", colorE, "preto :", colorD)
                        array_colors = array_colors[:12] + hsv_to_bytes(colorD) + hsv_to_bytes(colorE)
                    else:
                        start_index = menu_index * 4
                        array_colors = array_colors[:start_index] + hsv_to_bytes(colorD) + array_colors[start_index + 4:]
                        print(selected, ":", colorD)

            elif Button.LEFT in pressed:
                menu_index = (menu_index - 1) % len(menu_keys)
            elif Button.RIGHT in pressed:
                menu_index = (menu_index + 1) % len(menu_keys)

            selected = menu_keys[menu_index]
            hub.light.on(colors_copy[selected])

def ComparaHsv(hsv, color_name, sens=20):
    color = colors[color_name]
    hresult = abs(hsv.h - color.h) <= sens
    sresult = abs(hsv.s - color.s) <= sens
    vresult = abs(hsv.v - color.v) <= sens
    return hresult and sresult and vresult

def ChecaVerde():
    eColor = sensorE.hsv()
    dColor = sensorD.hsv()
    pitch = hub.imu.tilt()[0]
    if (ComparaHsv(eColor, "green") or ComparaHsv(dColor, "green")) and -5 < pitch < 5:
        print("verde")
        hub.speaker.beep(1000, 200)
        drive.stop()
        wait(500)
        drive.drive(60, 0)
        if ComparaHsv(eColor, "green") and ComparaHsv(dColor, "green"):
            print("verde BECO")
            VerdeVerde()
        
        elif ComparaHsv(eColor, "green"):
            print("verde ESQUERDA")
            while True:
                # Verifica dnv se é verde verde caso tenha passado e n viu
                if ComparaHsv(sensorD.hsv(), "green"):
                    print("verde verde")
                    VerdeVerde()
                    break
                if not ComparaHsv(sensorE.hsv(), "green"):
                    if ComparaHsv(sensorE.hsv(), "branco", 18):
                        print("branco")
                        break
                    elif ComparaHsv(sensorE.hsv(), "preto", 18):
                        Send("OCUPADO", 1)
                        SendBLE()
                        print("preto")
                        drive.straight(40)
                        drive.turn(30)
                        GiraAtePreto(120, 150, sensorE)
                        drive.turn(15)
                        wait(10)
                        break
                wait(50)

        elif ComparaHsv(dColor, "green"):
            print("verde DIREITA")
            while True:
                # Verifica dnv se é verde verde caso tenha passado e n viu
                if ComparaHsv(sensorE.hsv(), "green"):
                    print("verde verde")
                    VerdeVerde()
                    break
                if not ComparaHsv(sensorD.hsv(), "green"):
                    if ComparaHsv(sensorD.hsv(), "branco", 18):
                        print("branco")
                        break
                    elif ComparaHsv(sensorD.hsv(), "preto", 18):
                        Send("OCUPADO", 1)
                        SendBLE()
                        print("preto")
                        drive.straight(40)
                        drive.turn(-30)
                        GiraAtePreto(-120, 150, sensorD)
                        drive.turn(-15)
                        wait(10)
                        break
                wait(50)
def VerdeVerde():
    print("beco")
    while True:
        if not ComparaHsv(sensorD.hsv(), "green"):
            if ComparaHsv(sensorD.hsv(), "branco", 18):
                print("branco")
                break
            elif ComparaHsv(sensorD.hsv(), "preto", 18):
                Send("OCUPADO", 1)
                SendBLE()
                print("preto")
                drive.straight(30)
                drive.turn(-135)
                GiraAtePreto(-150, 150, sensorD)
                drive.turn(-15)
                wait(10)
                break
        wait(10)

def ChecaVermelho():
    global vermelho
    eColor = sensorE.hsv()
    dColor = sensorD.hsv()
    # print("E: ", ComparaHsv(eColor, "red", 20), "D: ", ComparaHsv(dColor, "red", 20))
    pitch = hub.imu.tilt()[0]
    # print("pitch: ", pitch)
    if ComparaHsv(eColor, "red") and ComparaHsv(dColor, "red") and -5 < pitch < 5:
        hub.speaker.beep(850, 200)
        vermelho = True
        return True
    return False

def ChecaObstaculo(lado=1):
    Send("OCUPADO", 1)
    SendBLE()
    pitch = hub.imu.tilt()[0]
    distancia = ultra.distance()
    if distancia < 50 and -5 < pitch < 5:
        drive.stop()
        drive.turn(-90 * lado)
        drive.straight(220)
        drive.turn(90 * lado)
        x = 3
        for _ in range(x):
            if MoveAtePreto(210, 210, 250, sensorE, sensorD):
                drive.straight(80)
                drive.turn(-45 * lado)
                if lado == 1:
                    GiraAtePreto(-150, 150, sensorD)
                else:
                    GiraAtePreto(150, 150, sensorE)

                drive.turn(-17 * lado)
                drive.straight(-25)
                drive.stop()
                return
            else:
                drive.straight(200)
                drive.turn(87 * lado)
    
    Send("OCUPADO", 0)

def Pid():
    global integral, last_error
    erro = sensorE.reflection() - sensorD.reflection()
    if abs(erro) < 10 and sensorD.reflection() > 50:
        erro = 0
    proporcional = erro * _KP
    integral += erro * _KI
    derivado = (erro - last_error) * _KD
    correcao = proporcional + integral + derivado
    motorE.run(forcaBase - correcao)
    motorD.run(forcaBase + correcao)
    last_error = erro

def MoveAtePreto(speed_left, speed_right, distance, sensorA, sensorB = None):
    motorE.reset_angle(0)
    motorD.reset_angle(0)

    target_angle = distance * (360 / (3.1416 * 36))

    while abs(motorE.angle()) < target_angle and abs(motorD.angle()) < target_angle:
        if sensorB == None:
            if ComparaHsv(sensorA.hsv(), "preto"):
                return True
        else:
            if ComparaHsv(sensorA.hsv(), "preto") or ComparaHsv(sensorB.hsv(), "preto"):
                return True
        motorE.run(speed_left)
        motorD.run(speed_right)

    motorE.stop()
    motorD.stop()
    return False

def GiraAtePreto(speed, distance, sensorA, sensorB = None):
    motorE.reset_angle(0)
    motorD.reset_angle(0)

    target_angle = distance * (360 / (3.1416 * 36))

    while abs(motorE.angle()) < target_angle and abs(motorD.angle()) < target_angle:
        if sensorB == None:
            if ComparaHsv(sensorA.hsv(), "preto"):
                break
        else:
            if ComparaHsv(sensorA.hsv(), "preto") or ComparaHsv(sensorB.hsv(), "preto"):
                break
        motorE.run(speed)
        motorD.run(-speed)

    hub.speaker.beep(900, 200)
    motorE.stop()
    motorD.stop()

def RetaUltra(speed_left, speed_right, distance, ultraDist, sensorA, sensorB = None):
    motorE.reset_angle(0)
    motorD.reset_angle(0)

    target_angle = distance * (360 / (3.1416 * 36))

    while abs(motorE.angle()) < target_angle and abs(motorD.angle()) < target_angle:
        if sensorB == None:
            if ComparaHsv(sensorA.hsv(), "preto", 18):
                print("preto")
                return "Preto"
        else:
            if ComparaHsv(sensorA.hsv(), "preto", 18) or ComparaHsv(sensorB.hsv(), "preto"):
                print("preto")
                return "Preto"
        if ultra.distance() <= ultraDist:
            print("parede")
            return "Parede"
        motorE.run(speed_left)
        motorD.run(speed_right)
        wait(100)

    motorE.stop()
    motorD.stop()
    print("distancia")
    return "Distancia"

def RetaInterrompida(speed_left, speed_right, distance, sens, sensorA, sensorB = None):
    motorE.reset_angle(0)
    motorD.reset_angle(0)

    target_angle = distance * (360 / (3.1416 * 36))

    while abs(motorE.angle()) < target_angle and abs(motorD.angle()) < target_angle:
        if sensorB == None:
            if ComparaHsv(sensorA.hsv(), "preto", 18):
                print("preto")
                return "Preto"
        else:
            if ComparaHsv(sensorA.hsv(), "preto", 18) or ComparaHsv(sensorB.hsv(), "preto"):
                print("preto")
                return "Preto"
        if abs(motorE.angle()) > 270:
            diferencaA = abs(abs(motorE.speed()) - abs(speed_left))
            diferencaB = abs(abs(motorD.speed()) - abs(speed_right))
            print("diferencaA: ", diferencaA, "diferencaB: ", diferencaB)
            if diferencaA > sens or diferencaB > sens:
                drive.stop()
                print("saiu")
                wait(1000)
                print("bateu")
                return "Bateu"
        motorE.run(speed_left)
        motorD.run(speed_right)

    drive.stop()
    motorE.stop()
    motorD.stop()
    print("distancia")
    return "Distancia"

def ChecaPrata():
    eColor = sensorE.hsv()
    dColor = sensorD.hsv()
    pitch = hub.imu.tilt()[0]
    if ComparaHsv(eColor, "prata") and ComparaHsv(dColor, "prata") and -5 < pitch < 5:
        print("prata")
        hub.speaker.beep(1000, 200)
        drive.stop()
        wait(500)
        Send("ESTADO", Estado.RESGATE)
        return True
    return False

def Resgate():
#Verifica se está no meio ou no canto----------------------------------------

    saidaMeio = 0
    saidasCanto = [0,0]
    drive.straight(220)
    drive.turn(-90)
    lado = 0
    drive.straight(50)
    wait(250)
    GetBLE()
    print("Frente: ",Read("FRFX"))
    if Read("FRFX") >= 5:
        lado = 1
        drive.straight(100)
        drive.straight(-50)
    else:
        drive.straight(-100)
        wait(250)
        GetBLE()
        print("Tras: ",Read("TRFX"))
        if Read("TRFX") >= 5:
            lado = -1
            drive.straight(-100)
        drive.straight(50)

    print("lado: ", lado)
    drive.turn(90)
    drive.turn(lado * 45)
    drive.straight(350 + abs(lado * 220))
    if not lado == 0:
        drive.turn(lado * -55)
    else:
        drive.turn(90)

#Pega vítimas nos meios----------------------------------------

    x = 4
    if lado == 0:
        x = 3
    for _ in range(x):
        Send("GARRA", Garra.ABERTA)
        SendBLE()
        wait(500)
        reta = RetaUltra(220, 220, 500, 120, sensorE, sensorD)
        Send("GARRA", Garra.FECHADA)
        SendBLE()
        wait(1500)

        if reta == "preto":
            saidaMeio = _
            drive.straight(-400)
        else:
            drive.straight(100)
            drive.straight(-450)
            
        if not lado == 0 or not _ == 3:
            drive.turn(-90)
        else:
            drive.turn(90)

    if lado == -1:
        drive.turn(45)
    else:
        drive.turn(-45)
    wait(250)

#Pega vítimas nos CANTOS
    verde = 0
    vermelho = 0
    if not lado == 0:
        x = 3
    for _ in range(x):
        Send("GARRA", Garra.ABERTA)
        SendBLE()
        wait(500)
        reta = RetaUltra(220, 220, 360, 120, sensorE, sensorD)
        Send("GARRA", Garra.FECHADA)
        SendBLE()
        wait(1500)

        drive.straight(120)
        wait(100)
        GetBLE()
        if Read("FCOR") == 0:
            print("canto vazio")
            hub.speaker.beep(1000, 200)
            wait(200)
            hub.speaker.beep(1000, 200)
            wait(200)
            hub.speaker.beep(1000, 200)

            if saidasCanto[0] == 0:
                drive.turn(-45)
                wait(100)
                if ultra.distance() >= 120:
                    saidasCanto[0] = _ 
                    saidasCanto[1] = -1
                drive.turn(90)
                wait(100)
                if ultra.distance() >= 120:
                    saidasCanto[0] = _
                    saidasCanto[1] = 1
                drive.turn(-45)
        else:
            print("canto triangulo")
            if Read("FCOR") == 1:
                verde = _
            elif Read("FCOR") == 2:
                vermelho = _

        drive.straight(-420)

        if lado == 0 and not _ == 4:
            drive.turn(90)
        elif not lado == 0 and not _ == 3:
            drive.turn(90 * lado)

    hub.speaker.beep(1000, 200)
    wait(200)
    hub.speaker.beep(1000, 200)

    print("saida meio: ", saidaMeio)
    print("saida canto: ", saidasCanto)

    virada = 0
    if not verde == 0: 
        triangulo = verde
    else:
        triangulo = vermelho
        
    if lado == 0:
        virada = (triangulo - 1) * 90
    else:
        virada = (triangulo - 1) * 90 * lado

    drive.turn(virada)

    drive.straight(-550)
    Send("PORTA", Porta.ABERTA)
    SendBLE()
    wait(1500)
    drive.settings(350)
    y = 2
    for _ in range(y):
        drive.straight(50)
        drive.straight(-60)
        wait(500)
    Send("PORTA", Porta.FECHADA)
    SendBLE()

    drive.straight(320)

    hub.speaker.beep(1000, 200)

    drive.turn(-virada)
    # wait(2000)
    # if lado == 0:
    #     drive.turn((triangulo - 4) * -90)
    # else:
    #     drive.turn((triangulo - 3) * -90 * lado)
    # drive.turn(saidasCanto[0] * 90 * lado)
    # drive.straight(320)
    # drive.turn(saidasCanto[1] * 45)

    Send("ESTADO", Estado.PLAY)
    SendBLE()
    wait(2000)

def Seguidor():
    ChecaObstaculo(-1)
    ChecaVerde()
    Send("OCUPADO", 0)
    if not ChecaVermelho():
        if not ChecaPrata():
            Pid()

def Play():
    global integral, last_error, vermelho
    integral = 0
    last_error = 0
    vermelho = False
    GetStoredColors(colors, colors_array)
    print(colors)

    Send("ESTADO", Estado.PLAY)

    WaitTheOtherHub()

    while True:
        GetBLE()

        print(vermelho)

        if CheckStopButton() or Read("ESTADO") == Estado.MAIN or vermelho:
            drive.stop()
            break

        if Send("ESTADO") == Estado.PLAY:
            Seguidor()
        elif Send("ESTADO") == Estado.RESGATE:
            Resgate()

        SendBLE()
        wait(10)

if __name__ == "__main__":
    # Send("GARRA", Garra.ABERTA)
    # SendBLE()
    while True:
        continue
