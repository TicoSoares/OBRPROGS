from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch

#Define hub e canais de informação do bluetooth
hub = PrimeHub(broadcast_channel=1, observe_channels=[2])
hub.system.set_stop_button(Button.CENTER)
hub.speaker.volume(50)

garra = Motor(Port.F)
porta = Motor(Port.B)
sensorF = ColorSensor(Port.D)
sensorT = ColorSensor(Port.C)
ultra = UltrasonicSensor(Port.E)

colors = [Color.GREEN,Color.GRAY,Color.BLACK,Color.WHITE]   

def ComparaHsv(hsv, color, tolerancia = 30):
    color_index = 0
    if color == "prata":
        color_index = 1
    elif color == "black":
        color_index = 2
    elif color == "white":
        color_index = 3
    
    hresult = abs(hsv.h - colors[color_index].h) <= tolerancia
    sresult = abs(hsv.s - colors[color_index].s) <= tolerancia
    vresult = abs(hsv.v - colors[color_index].v) <= tolerancia
    return hresult and sresult and vresult

def GetStoredColors(colors):
    stored_colors = [v for v in hub.system.storage(0, read=6)]
    colors[0] = Color(stored_colors[0], stored_colors[1], stored_colors[2])
    colors[1] = Color(stored_colors[3], stored_colors[4], stored_colors[5])
    print(colors)

def CheckStopButton():
    pressed = hub.buttons.pressed()
    return Button.CENTER in pressed

def Play():
    while True:
        if CheckStopButton():
            break
        
        if 