from pybricks.hubs import PrimeHub
from pybricks.parameters import Button, Color, Side
from pybricks.tools import wait

hub = PrimeHub()

import AnotaCores, Play, ExtraTools
from AnotaCores import AnotaCor
from Play import Play
from ExtraTools import GetButton, SetHubColor

menu_options = ("Cor", "NPid")
options_hue = (100, 0)
menu_index = 1
selected = menu_options[menu_index]
SetHubColor(options_hue[menu_index])

hub.system.set_stop_button((Button.LEFT, Button.CENTER))

def SelectProgram(program):
    if program == "Cor":
        AnotaCor()
    elif program == "NPid":
        Play()
        
while True:
    # Wait for any button.

    if hub.imu.ready():
        print("calibrou")
    else:
        print("NÃO calibrou")

    pressed = GetButton()
    # Now check which button was pressed.
    if Button.CENTER in pressed:
        testandoPID = False
        SetHubColor(options_hue[menu_index], 50)
        SelectProgram(selected)
    elif Button.LEFT in pressed:
        menu_index = (menu_index + 1) % len(menu_options)
    elif Button.RIGHT in pressed:
        menu_index = (menu_index - 1) % len(menu_options)
        
    SetHubColor(options_hue[menu_index])
    selected = menu_options[menu_index]
    wait(250)
