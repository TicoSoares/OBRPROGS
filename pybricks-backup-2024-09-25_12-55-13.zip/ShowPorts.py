from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor, ForceSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch

hub = PrimeHub()

device_names = {
    48: "SPIKE Medium Angular Motor",
    49: "SPIKE Large Angular Motor",
    61: "SPIKE Color Sensor",
    62: "SPIKE Ultrasonic Sensor",
    63: "SPIKE Force Sensor",
}

ports = [Port.A, Port.B, Port.C, Port.D, Port.E, Port.F]

def SeePorts():
    # Go through all available ports.
    for port in ports:
        # Try to get the device, if it is attached.
        try:
            device = PUPDevice(port)
        except OSError as ex:
            if ex.args[0] == ENODEV:
                # No device found on this port.
                print(port, ": ---")
                continue
            else:
                raise

        # Get the device id
        id = device.info()["id"]

        # Look up the name.
        try:
            print(port, ":", device_names[id])
        except KeyError:
            print(port, ":", "Dispositivo não reconhecido com id: ", id)

SeePorts()