from pybricks.pupdevices import Motor, ColorSensor
from pybricks.parameters import Button, Color, Port, Axis
from pybricks.tools import wait

from ExtraTools import *

motorGarra = Motor(Port.E)
motorPorta = Motor(Port.A)
sensorF = ColorSensor(Port.B)

hub.system.set_stop_button([Button.LEFT, Button.CENTER])

colors = {
    "green": Color.GREEN,
    "red": Color.RED
}
colors_copy = colors.copy()
colors_array = ["green", "red"]

def AnotaCor():
    global colors_copy

    Send("ESTADO", Estado.COR)
    hub.display.off()

    menu_keys = colors_array
    menu_index = 0

    selected = menu_keys[menu_index]
    hub.light.on(colors_copy[selected])

    array_colors = hub.system.storage(0, read=8)  # Inicializa o bytearray com tamanho 20

    while True:
        result = GetButton()
        pressed = time_pressed = None
        if result is None:
            break
        else:
            pressed, time_pressed = result
            if Button.CENTER in pressed:
                if time_pressed > 1000:
                    break
                else:
                    colorF = sensorF.hsv()

                    start_index = menu_index * 4
                    array_colors = array_colors[:start_index] + hsv_to_bytes(colorF) + array_colors[start_index + 4:]
                    print(selected, ":", colorF)
                
                hub.system.storage(0, write=array_colors)
                print(hub.system.storage(0, read=8))

            elif Button.LEFT in pressed:
                menu_index = (menu_index - 1) % len(menu_keys)
            elif Button.RIGHT in pressed:
                menu_index = (menu_index + 1) % len(menu_keys)

            selected = menu_keys[menu_index]
            hub.light.on(colors_copy[selected])

def ComparaHsv(hsv, color_name, sens=30):
    color = colors[color_name]
    hresult = abs(hsv.h - color.h) <= sens
    sresult = abs(hsv.s - color.s) <= sens
    vresult = abs(hsv.v - color.v) <= sens
    return hresult and sresult and vresult

def SetGarra(garraState, motorSpeed=300):
    target_angles = {2: -183, 3: -255}
    target_angle = target_angles.get(garraState, 0)
    diferenca = abs(motorGarra.angle()) - abs(target_angle)
    if abs(diferenca) < 5:
        return
    motorGarra.run_target(motorSpeed, target_angle)

def SetPorta(portaState, motorSpeed=300):
    target_angles = {2: -135}
    target_angle = target_angles.get(portaState, 0)
    diferenca = abs(motorPorta.angle()) - abs(target_angle)
    print("motor: ", motorPorta.angle(), "target: ", target_angle)
    print("diferenca: ", abs(diferenca))
    if abs(diferenca) < 5:
        return
    motorPorta.run_target(motorSpeed, target_angle)

def Seguidor():
    reflexF = sensorF.reflection()
    # reflexT = sensorT.reflection()
    Send("FRFX", reflexF)
    # Send("TRFX", reflexT)
    pitch = hub.imu.tilt()[0]
    print("pitch: ", pitch, "garra: ", motorGarra.angle())
    if Read("GARRA") == Garra.NONE:
        print("angular X:", hub.imu.angular_velocity(Axis.X), "angular Y:", hub.imu.angular_velocity(Axis.Y), "angular Z:", hub.imu.angular_velocity(Axis.Z))
        if pitch > 10 and abs(hub.imu.angular_velocity(Axis.Z)) < 10:
            Send("GARRA", Garra.ABERTA)
        elif -5 < pitch < 5:
            Send("GARRA", Garra.FECHADA)
    else:
        Send("GARRA", Read("GARRA"))

    SetGarra(Send("GARRA"))

def Resgate():
    reflexF = sensorF.reflection()
    # reflexT = sensorT.reflection()
    Send("FRFX", reflexF)
    # Send("TRFX", reflexT)
    if ComparaHsv(sensorF.hsv(), "green"):
        Send("FCOR", 1)
        print("FCOR: ", "verde")
    elif ComparaHsv(sensorF.hsv(), "red"):
        Send("FCOR", 2)
        print("FCOR: ", "vermelho")
    else:
        Send("FCOR", 0)
        print("FCOR: ", "")
    
    SendBLE()
    
    GetBLE()
    Send("GARRA", Read("GARRA"))
    SetGarra(Send("GARRA"))
    Send("PORTA", Read("PORTA"))
    SetPorta(Send("PORTA"))

def Play():

    Send("GARRA", Garra.FECHADA)
    Send("PORTA", Porta.FECHADA)
    Send("ESTADO", Estado.PLAY)

    motorGarra.reset_angle(0)
    motorPorta.reset_angle(0)
    GetStoredColors(colors, colors_array)
    print(colors)

    while True:
        GetBLE()

        if Read("ESTADO") == Estado.MAIN:
            motorGarra.stop()
            motorPorta.stop()
            break

        if Read("ESTADO") == Estado.RESGATE:
            Send("ESTADO", Estado.RESGATE)

        if not Read("OCUPADO"):
            if Send("ESTADO") == Estado.PLAY:
                Seguidor()
            elif Send("ESTADO") == Estado.RESGATE:
                Resgate()

        SendBLE()
        wait(100)

if __name__ == "__main__":
    while True:
        Send("ESTADO", Estado.MAIN)
        BlinkHubColor(0)

        while Read("ESTADO") == Send("ESTADO"):
            GetBLE()
            wait(10)
            
        if Read("ESTADO") == Estado.COR:
            AnotaCor()
        elif Read("ESTADO") == Estado.PLAY:
            Play()
