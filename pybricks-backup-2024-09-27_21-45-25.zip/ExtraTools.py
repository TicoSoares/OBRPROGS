from pybricks.hubs import PrimeHub
from pybricks.parameters import Button, Color, Port
from pybricks.tools import wait, StopWatch

hub = PrimeHub()
timer = StopWatch()

class Cima:
    BLE = 52

    ESTADO = 0
    GARRA = 1
    FCOR = 2
    FRFX = 3
    PORTA = 4

    SIZE = 7

class Baixo:
    BLE = 51

    ESTADO = 0
    OCUPADO = 1
    GARRA = 2
    PORTA = 3

    SIZE = 6

class Estado:
    MAIN = 0
    PLAY = 1
    RESGATE = 2
    COR = 3

class Garra:
    NONE = 0
    FECHADA = 1
    BAIXA = 2
    ABERTA = 3

class Porta:
    NONE = 0
    FECHADA = 1
    ABERTA = 2

class tReta:
    MEIO = 1
    CANTO = -1

class Area:
    VERTICAL = 0
    HORIZONTAL = 1
    QUADRADA = 2

thisHub = Cima if hub.system.name() == "HadesCima" else Baixo
otherHub = Baixo if hub.system.name() == "HadesCima" else Cima

sendData = bytearray(thisHub.SIZE)
readData = bytearray(otherHub.SIZE)

hub = PrimeHub(broadcast_channel=thisHub.BLE, observe_channels=[otherHub.BLE])
hub.speaker.volume(40)

def Read(attr=None):
    global readData, otherHub
    if attr is None:
        return readData
    else:
        return readData[getattr(otherHub, attr)]

def GetBLE():
    global readData, otherHub
    try:
        data = hub.ble.observe(otherHub.BLE)
        if data:
            readData = bytearray(data)
        else:
            return None
    except Exception as e:
        print(f"Error observing BLE data: {e}")
        return None

def Send(attr=None, value=None):
    global sendData, thisHub
    if attr is None:
        return sendData
    else:
        if value is None:
            return sendData[getattr(thisHub, attr)]
        else:
            sendData[getattr(thisHub, attr)] = value

def SendBLE():
    global sendData
    hub.ble.broadcast(sendData)

def EsperaHubCima():
    while CheckStopButton():
        wait(5)
    while True:
        GetBLE()
        if Read("ESTADO") == Send("ESTADO"):
            break

        if CheckStopButton():
            return

        SendBLE()
        wait(5)

def GetButton():
    pressed = ()
    while not pressed:
        pressed = hub.buttons.pressed()
        GetBLE()
        if Read("ESTADO") != Send("ESTADO"):
            if thisHub == Cima:
                return None
        SendBLE()
        wait(10)
    timer.reset()
    timer.resume()

    while hub.buttons.pressed():
        GetBLE()
        if Read("ESTADO") != Send("ESTADO"):
            if thisHub == Cima:
                return None
        SendBLE()
        wait(10)
    timer.pause()

    return pressed, timer.time()

def CheckStopButton():
    return Button.CENTER in hub.buttons.pressed()

def CheckAnyButton():
    return Button.CENTER in hub.buttons.pressed() or Button.LEFT in hub.buttons.pressed() or Button.RIGHT in hub.buttons.pressed()

def SetHubColor(h, v=100):
    new_color = Color(h, 100, v)
    hub.light.on(new_color)

def BlinkHubColor(h, v=100):
    new_color = Color(h, 100, v)
    hub.light.blink(new_color, [250, 250])

def hsv_to_bytes(hsv):
    # Ajustar o valor de Hue para caber em 2 bytes (0-65535)
    h_int = int(hsv.h / 360 * 65535)
    h_bytes = h_int.to_bytes(2, 'big')

    # Saturation e Value já estão entre 0 e 100, ajustar para caber em 1 byte (0-255)
    s_byte = int(hsv.s / 100 * 255).to_bytes(1, 'big')
    v_byte = int(hsv.v / 100 * 255).to_bytes(1, 'big')

    return h_bytes + s_byte + v_byte

def bytes_to_hsv(hsv_bytes):
    # Lê os 2 primeiros bytes como Hue (0-65535) e converte para 0-360
    h = int.from_bytes(hsv_bytes[0:2], 'big') * 360 / 65535

    # Lê o próximo byte como Saturation (0-255) e converte para 0-100
    s = int.from_bytes(hsv_bytes[2:3], 'big') * 100 / 255

    # Lê o último byte como Value (0-255) e converte para 0-100
    v = int.from_bytes(hsv_bytes[3:4], 'big') * 100 / 255

    # Retorna como uma tupla (h, s, v)
    return Color(h,s,v)

def GetStoredColors(colors, colors_array):
    # Inicializa o bytearray com os dados armazenados na memória
    byte_data = hub.system.storage(0, read=20)

    def bytes_to_color(start_index):
        """Converte os bytes armazenados em um objeto Color."""
        hsv_bytes = byte_data[start_index:start_index + 4]
        hsv = bytes_to_hsv(hsv_bytes)
        return hsv

    index = 0
    while index < len(colors_array):
        key = colors_array[index]
        start_index = index * 4

        if key == "branco":
            if start_index + 8 <= len(byte_data):
                colors[key] = bytes_to_color(start_index + 4)
                colors["preto"] = bytes_to_color(start_index)
            else:
                colors[key] = Color.BLACK
                colors["preto"] = Color.BLACK
            index += 2  # Pula para o próximo conjunto de cores
        else:
            if start_index + 4 <= len(byte_data):
                colors[key] = bytes_to_color(start_index)
            else:
                colors[key] = Color.BLACK
            index += 1