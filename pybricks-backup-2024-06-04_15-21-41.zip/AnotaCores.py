from pybricks.hubs import PrimeHub
from pybricks.pupdevices import ColorSensor
from pybricks.parameters import Button, Color, Port
from pybricks.tools import wait, StopWatch

hub = PrimeHub()

from ExtraTools import GetButton

timer = StopWatch()
timer.pause()
timer.reset()

sensorD = ColorSensor(Port.A)

def AnotaCor():
    while True:
        pressed = ()
        while not pressed:
            pressed = hub.buttons.pressed()
            wait(10)
        timer.resume()
        # Wait for the button to be released.
        while hub.buttons.pressed():
            wait(10)
        timer.pause()
        #Espera algum botão ser apertado
        colorhsv = sensorD.hsv()
        hsv = [colorhsv.h, colorhsv.s, colorhsv.v]
        print(hsv)

        #Sai do modo de anotar cor
        if Button.CENTER in pressed:
            break
        # Anota Fita Prata
        elif Button.LEFT in pressed:
            if timer.time() < 1000:
                hub.system.storage(0, write=bytes(hsv))
                print("Verde: " + str(hsv))
            else:
                hub.system.storage(9, write=bytes(hsv))
                print("Branco: " + str(hsv))
        # Anota Fita VERDE
        elif Button.RIGHT in pressed:
            if timer.time() < 1000:
                hub.system.storage(3, write=bytes(hsv))
                print("Prata: " + str(hsv))
            else:
                hub.system.storage(6, write=bytes(hsv))
                print("Preto: " + str(hsv))
        wait(500)