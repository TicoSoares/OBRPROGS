from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor
from pybricks.parameters import Button, Color, Direction, Port
from pybricks.robotics import DriveBase
from pybricks.tools import wait, multitask, run_task

from ExtraTools import *

# Define as Portas
sensorD = ColorSensor(Port.A)
sensorE = ColorSensor(Port.B)
ultra = UltrasonicSensor(Port.D)
motorD = Motor(Port.C)
motorE = Motor(Port.E, Direction.COUNTERCLOCKWISE)

colors = {
    "green": Color.GREEN,
    "prata": Color.GRAY,
    "red": Color.RED,
    "preto": Color.BLACK,
    "branco": Color.WHITE
}
colors_copy = colors.copy()
colors_array = ["green", "prata", "red", "branco"]

pid_erro = 0
integral = 0
last_error = 0

vermelho = False

forcaBase = 210
_KP = 10.15  
_KI = 0.0
_KD = 2.0
erro_vel_fator = 1.8

# Define motores de movimento
drive = DriveBase(motorE, motorD, wheel_diameter=40, axle_track=200)

def AnotaCor():
    global colors_note

    Send("ESTADO", Estado.COR)
    hub.display.off()

    menu_keys = colors_array
    menu_index = 0

    selected = menu_keys[menu_index]
    hub.light.on(colors_copy[selected])

    array_colors = hub.system.storage(0, read=20) 

    while True:
        result = GetButton()
        pressed = time_pressed = None
        if result is None:
            break
        else:
            pressed, time_pressed = result

        if result is not None:
            pressed, time_pressed = result
            if Button.CENTER in pressed:
                if time_pressed > 1000:
                    break
                else:
                    colorE = sensorE.hsv()
                    colorD = sensorD.hsv()

                    if selected == "branco":
                        print("branco :", colorE, "preto :", colorD)
                        array_colors = array_colors[:12] + hsv_to_bytes(colorD) + hsv_to_bytes(colorE)
                    else:
                        start_index = menu_index * 4
                        array_colors = array_colors[:start_index] + hsv_to_bytes(colorD) + array_colors[start_index + 4:]
                        print(selected, ":", colorD)
                    
                    hub.system.storage(0, write=array_colors)

            elif Button.LEFT in pressed:
                menu_index = (menu_index - 1) % len(menu_keys)
            elif Button.RIGHT in pressed:
                menu_index = (menu_index + 1) % len(menu_keys)

            selected = menu_keys[menu_index]
            hub.light.on(colors_copy[selected])

def LadoObstaculo():
    hub.display.off()

    while True:
        result = GetButton()
        pressed = time_pressed = None
        if result is None:
            break
        else:
            pressed, time_pressed = result

        if result is not None:
            pressed, time_pressed = result
            if Button.CENTER in pressed:
                break
            elif Button.RIGHT in pressed:
                hub.system.storage(20, write=bytes([1]))
                break
            elif Button.LEFT in pressed:
                hub.system.storage(20, write=bytes([0]))
                break

def TipoArena():
    hub.display.off()

    while True:
        result = GetButton()
        pressed = time_pressed = None
        if result is None:
            break
        else:
            pressed, time_pressed = result

        if result is not None:
            pressed, time_pressed = result
            if Button.CENTER in pressed:
                if time_pressed > 1000:
                    break
                else:
                    print("quadrado")
                    hub.system.storage(21, write=bytes([2]))
                    break
            elif Button.RIGHT in pressed:
                print("vertical")
                hub.system.storage(21, write=bytes([0]))
                break
            elif Button.LEFT in pressed:
                print("horizontal")
                hub.system.storage(21, write=bytes([1]))
                break

def ComparaHsv(hsv, color_name, sens=20):
    color = colors[color_name]
    hresult = abs(hsv.h - color.h) <= sens
    sresult = abs(hsv.s - color.s) <= sens
    vresult = abs(hsv.v - color.v) <= sens
    return hresult and sresult and vresult

def ChecaCores():
    global vermelho
    eColor = sensorE.hsv()
    dColor = sensorD.hsv()
    pitch = hub.imu.tilt()[0]
    if (ComparaHsv(eColor, "green") or ComparaHsv(dColor, "green")) and -5 < pitch < 5:
        sensorA = sensorE
        sensorB = sensorD
        lado_verde = 1
        print("verde")
        hub.speaker.beep(1000, 200)
        drive.stop()
        wait(100)
        drive.drive(60, 0)
        if ComparaHsv(eColor, "green") and ComparaHsv(dColor, "green"):
            print("verde BECO")
            VerdeVerde()
        elif ComparaHsv(dColor, "green"):
            sensorA = sensorD
            sensorB = sensorE
            lado_verde = -1

        giro_preciso(-15 * lado_verde)
        drive.drive(60, 0)
        while True:
            # Verifica dnv se é verde verde caso tenha passado e n viu
            if ComparaHsv(sensorB.hsv(), "green"):
                print("verde verde")
                VerdeVerde()
                break
            if not ComparaHsv(sensorA.hsv(), "green"):
                if ComparaHsv(sensorA.hsv(), "branco", 5):
                    giro_preciso(25 * lado_verde)
                    print("branco")
                    break
                elif ComparaHsv(sensorA.hsv(), "preto", 25):
                    Send("OCUPADO", 1)
                    SendBLE()
                    print("preto")
                    drive.straight(40)
                    giro_preciso(30 * lado_verde)
                    MoveAtePreto(-300 * lado_verde,300 * lado_verde, 150, sensorA)
                    giro_preciso(20 * lado_verde)
                    drive.straight(40)
                    break

    elif ComparaHsv(eColor, "red") and ComparaHsv(dColor, "red") and -5 < pitch < 5:
        hub.speaker.beep(850, 200)
        vermelho = True
        return "Vermelho"

    elif ComparaHsv(eColor, "prata", 5) and ComparaHsv(dColor, "prata", 5) and -5 < pitch < 5:
        print("prata")
        drive.stop()
        hub.speaker.beep(1000, 100)
        giro = MoveAtePreto(250, 60, sensorD)
        if not giro == "Preto":
            giro_preciso(-45)
            Send("ESTADO", Estado.RESGATE)
            return "Prata"
        hub.speaker.beep(1000, 100)
        giro_preciso(-45)
    return 

def VerdeVerde():
    print("beco")
    while True:
        if not ComparaHsv(sensorD.hsv(), "green"):
            if ComparaHsv(sensorD.hsv(), "branco", 5):
                print("branco")
                drive.stop()
                break
            elif ComparaHsv(sensorD.hsv(), "preto", 25):
                Send("OCUPADO", 1)
                SendBLE()
                print("preto")
                drive.straight(30)
                giro_preciso(-180)
                drive.straight(20)
                break

def ChecaObstaculo(lado=1):
    Send("OCUPADO", 1)
    SendBLE()
    pitch = hub.imu.tilt()[0]
    distancia = ultra.distance()
    ultra_factor = 0.0
    if distancia < 50:
        drive.brake()
        wait(100)
        if ultra.distance() <= 50:
            drive.stop()
            giro_preciso(-90 * lado)
            drive.straight(220)
            giro_preciso(90 * lado)
            x = 3
            for _ in range(x):
                if MoveAtePreto(450, 450, 250, sensorE, sensorD):
                    drive.straight(59)
                    giro_preciso(-45 * lado)
                    if lado == 1:
                        MoveAtePreto(-400, 400, 150, sensorD)
                    else:
                        MoveAtePreto(400, -400, 150, sensorE)

                    giro_preciso(-10 * lado)
                    drive.straight(-25)
                    return
                else:
                    drive.straight(160)
                    giro_preciso(90 * lado)
    Send("OCUPADO", 0)

def Pid():
    global integral, last_error, pid_erro, erro_vel_fator
    pid_erro = sensorE.reflection() - sensorD.reflection()
    if abs(pid_erro) < 10 and sensorD.reflection() > 50:
        pid_erro = 0
    proporcional = pid_erro * _KP
    integral += pid_erro * _KI
    derivado = (pid_erro - last_error) * _KD
    correcao = proporcional + integral + derivado
    negativeForce = abs(pid_erro) * erro_vel_fator
    motorE.run((forcaBase - negativeForce) - correcao)
    motorD.run((forcaBase - negativeForce) + correcao)
    last_error = pid_erro

def MoveAtePreto(lef_speed, right_speed, distance, sensorA, sensorB = None):
    motorE.reset_angle(0)
    motorD.reset_angle(0)

    target_angle = distance * (360 / (3.1416 * 36))

    while abs(motorE.angle()) < target_angle and abs(motorD.angle()) < target_angle:
        if sensorB == None:
            if ComparaHsv(sensorA.hsv(), "preto"):
                return "Preto"
        else:
            if ComparaHsv(sensorA.hsv(), "preto") or ComparaHsv(sensorB.hsv(), "preto"):
                return "Preto"
        motorE.run(lef_speed)
        motorD.run(right_speed)

    hub.speaker.beep(900, 200)
    motorE.stop()
    motorD.stop()
    return "Distancia"

def RetaUltra(speed_left, speed_right, distance, ultraDist, factor, paraNoPreto = False):
    motorE.reset_angle(0)
    motorD.reset_angle(0)

    target_angle = distance * (360 / (3.1416 * 36))
    # target_angle = distance * 3.19

    ultra_factor = 0

    while distance == 0 or (abs(motorE.angle()) < target_angle and abs(motorD.angle()) < target_angle ):
        # angle_percorrido = (abs(motorE.angle()) + abs(motorD.angle())) / 2
        # dist_percorrida = angle_percorrido / 3.19
        if paraNoPreto:
            if ComparaHsv(sensorE.hsv(), "preto", 18) or ComparaHsv(sensorD.hsv(), "preto", 18):
                drive.stop()
                print("preto")
                return "Preto"

        if ultra.distance() <= ultraDist:
            ultra_factor += 1
            if ultra_factor > factor:
                drive.stop()
                drive.straight(50)
                print("parede")
                return "Parede"
        else:
            ultra_factor = 0

        motorE.run(speed_left)
        motorD.run(speed_right)
        wait(100)

    drive.stop()
    print("distancia")
    return "Distancia"

def RetaInterrompida(speed_left, speed_right, distance, sens, angl_motor = 180, paraNoPreto = False):
    motorE.reset_angle(0)
    motorD.reset_angle(0)

    target_angle = distance * (360 / (3.1416 * 36))

    while abs(motorE.angle()) < target_angle and abs(motorD.angle()) < target_angle:
        if paraNoPreto:
            if ComparaHsv(sensorE.hsv(), "preto", 18) or ComparaHsv(sensorD.hsv(), "preto"):
                print("preto")
                return "Preto"
        if abs(motorE.angle()) > 180:
            diferencaA = abs(abs(motorE.speed()) - abs(speed_left))
            diferencaB = abs(abs(motorD.speed()) - abs(speed_right))
            if diferencaA > sens or diferencaB > sens:
                drive.stop()
                print("bateu")
                return "Bateu"
        motorE.run(speed_left)
        motorD.run(speed_right)

    drive.stop()
    motorE.stop()
    motorD.stop()
    print("distancia")
    return "Distancia"

def angle_preciso(angulo_desejado, velocidade=400, margem = 3):
    while True:
        angulo_atual = hub.imu.heading()  # Atualiza o ângulo atual
        erro = angulo_desejado - angulo_atual 

        if abs(erro) < margem:  # Se o erro for menor que 2 graus, parar
            break

        # Controla a velocidade do motor proporcional ao erro
        velocidade_ajustada = velocidade if erro < 0 else -velocidade
        motorE.run(velocidade_ajustada)
        motorD.run(-velocidade_ajustada)
        
        wait(10)

    # Parar os motores
    motorE.stop()
    motorD.stop()
    wait(100)

def giro_preciso(angulo_desejado, velocidade=400, margem = 3):
    angulo_inicial = hub.imu.heading()  # Obtém o ângulo inicial
    angulo_alvo = angulo_inicial - angulo_desejado

    while True:
        angulo_atual = hub.imu.heading()  # Atualiza o ângulo atual
        erro = angulo_alvo - angulo_atual 

        if abs(erro) < margem:  # Se o erro for menor que 2 graus, parar
            break

        # Controla a velocidade do motor proporcional ao erro
        velocidade_ajustada = velocidade if erro < 0 else -velocidade
        motorE.run(velocidade_ajustada)
        motorD.run(-velocidade_ajustada)
        
        wait(10)

    # Parar os motores
    motorE.stop()
    motorD.stop()
    wait(100)
    
def ultra_preciso(dist_desejada, velocidade=400, margem = 1):
    while True:
        dist_atual = ultra.distance()  # Atualiza o ângulo atual
        erro = dist_desejada - dist_atual 

        if abs(erro) < margem:  # Se o erro for menor que 2 graus, parar
            break

        # Controla a velocidade do motor proporcional ao erro
        velocidade_ajustada = velocidade if erro < 0 else -velocidade
        motorE.run(velocidade_ajustada)
        motorD.run(velocidade_ajustada)
        
        wait(10)

    # Parar os motores
    motorE.stop()
    motorD.stop()

def Resgate():
#Verifica se está no meio ou no canto----------------------------------------
    vel_giro = 620
    tipo_arena = int.from_bytes(hub.system.storage(21, 1), 'big')
    print(tipo_arena)
    if tipo_arena == Arena.VERTICAL:
        print("Vertical")
    elif tipo_arena == Arena.HORIZONTAL:
        print("Horizontal")
    else:
        print("Quadrado")

    reta = ""

    saidaMeio = -1
    saidaCanto = -1
    drive.straight(220)
    giro_preciso(-90, vel_giro)
    lado = 0
    RetaInterrompida(700, 700, 100, 210, 90)
    wait(250)
    GetBLE()
    print("Frente: ",Read("FRFX"))
    if Read("FRFX") >= 5:
        lado = 1
        RetaInterrompida(700, 700, 100, 190, 90)
        drive.straight(-100)
    else:
        RetaInterrompida(-700, -700, 160, 190)
        wait(250)
        GetBLE()
        print("Tras: ",Read("TRFX"))
        if Read("TRFX") >= 5:
            lado = -1
            RetaInterrompida(-700, -700, 100, 210, 90)
        drive.straight(50)

    print("lado: ", lado)
    girinho = 0
    hub.imu.reset_heading(-90)
    if tipo_arena == Arena.HORIZONTAL:
        girinho = lado * 55
    elif tipo_arena == Arena.VERTICAL:
        girinho = lado * 30
    else:
        girinho = lado * 45
    giro_preciso(90 + girinho, vel_giro)
    hub.imu.reset_heading(0)


    if tipo_arena == Arena.VERTICAL:
        if lado == 0:
            drive.straight(700)
    else:
        drive.straight(350 + abs(lado * 300))
    if not lado == 0:
        if tipo_arena == Arena.HORIZONTAL:
            giro_preciso(lado * -55, vel_giro)
        elif tipo_arena == Arena.VERTICAL:
            giro_preciso(lado * -30, vel_giro)
        else:
            giro_preciso(lado * -45, vel_giro)
    else:
        giro_preciso(90, vel_giro)

#Pega vítimas nos meios----------------------------------------

    x = 4
    if lado == 0:
        x = 3
    for _ in range(x):
        Send("GARRA", Garra.ABERTA)
        SendBLE()
        wait(500)
        reta = RetaUltra(700, 700, 0, 200, 2, True)
        if reta == "Parede":
            ultra_preciso(90, 200, 2.35)
            drive.straight(-20)
        
        Send("GARRA", Garra.FECHADA)
        SendBLE()
        wait(850)

        if reta == "Preto":
            saidaMeio = _
        else:
            RetaInterrompida(700, 700, 150, 200)

        if tipo_arena == Arena.QUADRADA:
            drive.straight(-445)
        else:
            retinha = _ + 1 if lado == 0 else _
            if retinha % 2 == tipo_arena:
                print("maior")
                drive.straight(-630)
            else:
                print("menor")
                drive.straight(-445)
            
        if not lado == 0 or (lado == 0 and not _ == 2):
            giro_preciso(-90, vel_giro)
        else:
            if not lado == 0:
                giro_preciso(90, vel_giro)

    if lado == 1:
        giro_preciso(-45, vel_giro)
    else:
        giro_preciso(45, vel_giro)

#Pega vítimas nos CANTOS
    tri_verde = -1
    tri_vermelho = 0
    x = 4
    if not lado == 0:
        x = 3
    for _ in range(x):
        Send("GARRA", Garra.ABERTA)
        SendBLE()
        wait(500)
        if tipo_arena == Arena.QUADRADA:
            reta = RetaUltra(700, 700, 300, 210, 3)
        else:
            reta = RetaUltra(700, 700, 400, 210, 3)
        if reta == "Parede":
            ultra_preciso(90, 200, 2.35)
            drive.straight(-20)
        Send("GARRA", Garra.FECHADA)
        SendBLE()
        wait(850)
        RetaInterrompida(700, 700, 140, 200)
        wait(500)
        GetBLE()
        wait(100)
        if not Read("FCOR") == 0 and reta == "Parede":
            print("canto triangulo")
            if Read("FCOR") == 1:
                tri_verde = _
            elif Read("FCOR") == 2:
                tri_vermelho = _

            if tipo_arena == Arena.QUADRADA:
                drive.straight(-450)
            else:
                drive.straight(-500)
            
        else:
            hub.speaker.beep(900, 100)
            print("canto: ", saidaCanto, "meio: ", saidaMeio)
            if saidaCanto < 0 and saidaMeio < 0:
                giro_preciso(-30, vel_giro)
                wait(100)
                if ultra.distance() >= 200:
                    saidaCanto = _ * 2
                giro_preciso(60, vel_giro)
                wait(100)
                if ultra.distance() >= 200:
                    saidaCanto = _ * 2 + 1
                giro_preciso(-30, vel_giro)  
            if tipo_arena == Arena.QUADRADA:
                drive.straight(-500)
            else:
                drive.straight(-500)

        if lado == 0:
            giro_preciso(90, vel_giro)
        elif not lado == 0 and not _ == 3:
            giro_preciso(90 * lado, vel_giro)
        
    print("saida meio: ", saidaMeio)
    print("saida canto: ", saidaCanto)
    print("triangulo verde:", tri_verde, "triangulo vermelho:", tri_vermelho)

    virada = 0
    if tri_verde >= 0: 
        triangulo = tri_verde
    else:
        triangulo = tri_vermelho
    
    if lado == 0:
        if triangulo == 0:
            virada = 180
        elif triangulo == 1:
            virada = -90
        elif triangulo == 3: 
            virada = 90            
    else:
        virada = (triangulo - 1) * 90 * lado

    if lado == 0:
        angle = hub.imu.heading() - 45
    else:
        angle = hub.imu.heading()

    giro_preciso(virada, vel_giro)
    
    if tipo_arena == Arena.QUADRADA:
        drive.straight(-350)
    else:
        drive.straight(-400)
    RetaInterrompida(-800,-800, 300, 210)
    Send("PORTA", Porta.ABERTA)
    SendBLE()
    wait(1000)
    Send("PORTA", Porta.FECHADA)
    SendBLE()
    if tipo_arena == Arena.QUADRADA:
        drive.straight(420)
    else:
        drive.straight(500)

    if lado == 0:
        angle_preciso(angle, vel_giro + 500)
    else:
        angle_preciso(angle - 135 * lado, vel_giro + 500)

    #valor default de saida
    if saidaMeio < 0 and saidaCanto < 0:
        saidaCanto = 1

    vel_giro += 200
    lado_sem_zero = lado if lado != 0 else 1

    if saidaMeio >= 0:
        if lado == 0:
            giro_preciso(90 * (saidaMeio - 1), vel_giro)
        else:
            giro_preciso(90 * saidaMeio * lado, vel_giro)
        if tipo_arena == Arena.QUADRADA:
            drive.straight(-300)
        else:
            if _ % 2 == tipo_arena:
                print("maior")
                drive.straight(-500)
            else:
                print("menor")
                drive.straight(-300)
    else:
        if lado == 0 and (saidaCanto == 4 or saidaCanto == 7):
            giro_preciso(90 * 1 if saidaCanto == 4 else -1)
            RetaUltra(900,900, 0, 120,3)
            RetaInterrompida(900,900, 120, 220)
            drive.straight(-60)
            giro_preciso(-90 * 1 if saidaCanto == 4 else -1)
            RetaUltra(900,900, 0, 120,3)
            RetaInterrompida(900,900, 120, 220)
            drive.straight(-60)
            giro_preciso(90 * 1 if saidaCanto == 4 else -1)

        else:
            if saidaCanto == 4 or saidaCanto == 7:
                giro_preciso(180)

            elif saidaCanto == 1 or saidaCanto == 6:
                giro_preciso(-90 * lado_sem_zero)

            elif saidaCanto == 2 or saidaCanto == 5:
                giro_preciso(90 * lado_sem_zero)

            RetaUltra(900,900, 0, 120,3)
            RetaInterrompida(900,900, 120, 220, 90)
            drive.straight(-60)

            if saidaCanto % 2 == 0:
                giro_preciso(-90 * lado_sem_zero)
            else:
                giro_preciso(90 * lado_sem_zero)
            if tipo_arena == Arena.QUADRADA:
                drive.straight(400)
            else:
                drive.straight(500)

    Send("ESTADO", Estado.PLAY)
    SendBLE()

def Seguidor():
    ChecaObstaculo((int.from_bytes(hub.system.storage(20, 1), 'big') * 2) - 1)
    cor = ChecaCores()
    Send("OCUPADO", 0)
    if not cor == "Prata" or not cor == "Vermelho"
        Pid()

def Play():
    global integral, last_error, vermelho
    integral = 0
    last_error = 0
    vermelho = False
    GetStoredColors(colors, colors_array)
    Send("ESTADO", Estado.PLAY)

    EsperaHubCima()

    while True:
        GetBLE()
        if vermelho:
            drive.stop()
            break

        if Send("ESTADO") == Estado.PLAY:
            drive.settings(675)
            Seguidor()
        elif Send("ESTADO") == Estado.RESGATE:
            drive.settings(675)
            Resgate()

        SendBLE()

if __name__ == "__main__":
    while True:
        RetaInterrompida(900, 900, 150, 250)
        wait(500)

        
