from pybricks.hubs import PrimeHub
from pybricks.pupdevices import ColorSensor
from pybricks.parameters import Button, Color, Port
from pybricks.tools import wait

hub = PrimeHub()

sensorD = ColorSensor(Port.A)

def AnotaCor():
    while True:

        #Espera algum botão ser apertado
        pressed = GetButton()
        hsv = [v for v in sensorD.hsv()]

        #Sai do modo de anotar cor
        if Button.CENTER in pressed:
            break
        # Anota Fita Prata
        elif Button.LEFT in pressed:
            hub.system.storage(3, write=bytes(hsv))
            print("Prata: " + str(hsv))
        # Anota Fita VERDE
        elif Button.RIGHT in pressed:
            hub.system.storage(0, write=bytes(hsv))
            print("Verde: " + str(hsv))
        
        wait(500)