from pybricks.hubs import PrimeHub
from pybricks.parameters import Button, Color
from pybricks.tools import wait

hub = PrimeHub()

import AnotaCores, Seguidor, ExtraTools

menu_options = ("Cor", "Pid")
menu_color = (Color(100, 100, 100), Color(0, 100, 100))
menu_index = 0
selected = "Cor"

hub.system.set_stop_button((Button.LEFT, Button.CENTER))

while True:
    # Wait for any button.
    pressed = GetButton()
    # Now check which button was pressed.
    if Button.CENTER in pressed:
        SetHubColor(menu_color[menu_index], 50)
        SelectProgram(selected)
        return
    elif Button.LEFT in pressed:
        menu_index = (menu_index + 1) % len(menu_options)
    elif Button.RIGHT in pressed:
        menu_index = (menu_index - 1) % len(menu_options)

    SetHubColor(menu_color[menu_index])
    selected = menu_options[menu_index]
    wait(250)

def SelectProgram(program)
    if program == "Cor":
        AnotaCores()
    elif program == "Pid":
        Seguidor()