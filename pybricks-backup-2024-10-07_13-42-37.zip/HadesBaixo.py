from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor
from pybricks.parameters import Button, Color, Direction, Port, Axis
from pybricks.robotics import DriveBase
from pybricks.tools import wait

from ExtraTools import *

sensorD = ColorSensor(Port.A)
sensorE = ColorSensor(Port.C)
ultraF = UltrasonicSensor(Port.E)
ultraT = UltrasonicSensor(Port.F)
motorD = Motor(Port.B, Direction.COUNTERCLOCKWISE)
motorE = Motor(Port.D)
drive = DriveBase(motorE, motorD, 30.9, 137.5)
drive.settings(539.9999, 5393.99, 100)
default_settings = drive.settings()
drive.use_gyro(True)

colors = {
    "green": Color.GREEN,
    "prata": Color.VIOLET,
    "red": Color.RED,
    "preto": Color.BLACK,
    "branco": Color.WHITE
}
colors_copy = colors.copy()
colors_array = ["green", "prata", "red", "branco"]

pid_erro = 0
integral = 0
last_error = 0

vermelho = False

erro_vel_factor = 2
forcaBase = 500
vel_virada = 400
_KP = 14
_KI = 0.0
_KD = 3.6

timer_noventa = StopWatch()
timer_noventa.pause()

def AnotaCor():
    global colors_note

    Send("ESTADO", Estado.COR)
    hub.display.off()

    menu_keys = colors_array
    menu_index = 0

    selected = menu_keys[menu_index]
    hub.light.on(colors_copy[selected])

    array_colors = hub.system.storage(0, read=20) 

    while True:
        result = GetButton()
        pressed = time_pressed = None
        if result is None:
            break
        else:
            pressed, time_pressed = result
            if Button.CENTER in pressed:
                if time_pressed > 500:
                    break
                else:
                    colorE = sensorE.hsv()
                    colorD = sensorD.hsv()

                    if selected == "branco":
                        print("branco :", colorE, "preto :", colorD)
                        array_colors = array_colors[:12] + hsv_to_bytes(colorD) + hsv_to_bytes(colorE)
                    else:
                        start_index = menu_index * 4
                        array_colors = array_colors[:start_index] + hsv_to_bytes(colorD) + array_colors[start_index + 4:]
                        print(selected, ":", colorD)

                    hub.system.storage(0, write=array_colors)
                    print(hub.system.storage(0, read=20))

            elif Button.LEFT in pressed:
                menu_index = (menu_index - 1) % len(menu_keys)
            elif Button.RIGHT in pressed:
                menu_index = (menu_index + 1) % len(menu_keys)

            selected = menu_keys[menu_index]
            hub.light.on(colors_copy[selected])

def LadoObstaculo():
    hub.display.off()

    while True:
        result = GetButton()
        pressed = time_pressed = None
        if result is None:
            break
        else:
            pressed, time_pressed = result
            if Button.CENTER in pressed:
                break
            elif Button.RIGHT in pressed:
                hub.system.storage(20, write=bytes([1]))
                break
            elif Button.LEFT in pressed:
                hub.system.storage(20, write=bytes([0]))
                break

def TipoArea():
    hub.display.off()

    while True:
        result = GetButton()
        pressed = time_pressed = None
        if result is None:
            break
        else:
            pressed, time_pressed = result
            if Button.CENTER in pressed:
                if time_pressed > 1000:
                    break
                else:
                    print("quadrado")
                    hub.system.storage(21, write=bytes([2]))
                    break
            elif Button.RIGHT in pressed:
                print("vertical")
                hub.system.storage(21, write=bytes([0]))
                break
            elif Button.LEFT in pressed:
                print("horizontal")
                hub.system.storage(21, write=bytes([1]))
                break

def ComparaHsv(hsv, color_name, sens=20):
    color = colors[color_name]
    hresult = abs(hsv.h - color.h) <= sens
    sresult = abs(hsv.s - color.s) <= sens
    vresult = abs(hsv.v - color.v) <= sens
    return hresult and sresult and vresult

def ChecaCores():
    eColor = sensorE.hsv()
    dColor = sensorD.hsv()
    pitch = hub.imu.tilt()[0]

    if (ComparaHsv(eColor, "green") or ComparaHsv(dColor, "green")) and -5 < pitch < 5 and timer_noventa.time() == 0:
        sensorA = sensorD
        sensorB = sensorE
        lado_verde = -1
        print("verde")
        hub.speaker.beep(1000, 200)
        drive.stop()
        wait(500)
        drive.drive(60, 0)
        if ComparaHsv(eColor, "green") and ComparaHsv(dColor, "green"):
            print("verde BECO")
            VerdeVerde()
        elif ComparaHsv(eColor, "green"):
            sensorA = sensorE
            sensorB = sensorD
            lado_verde = 1
        
        drive.turn(15 * lado_verde)
        drive.straight(-15)
        drive.drive(60, 0)
        while True:
            # Verifica dnv se é verde verde caso tenha passado e n viu
            if ComparaHsv(sensorB.hsv(), "green"):
                print("verde verde")
                VerdeVerde()
                break
            if not ComparaHsv(sensorA.hsv(), "green"):
                if ComparaHsv(sensorA.hsv(), "branco", 10):
                    drive.turn(-25*lado_verde)
                    print("branco")
                    break
                elif ComparaHsv(sensorA.hsv(), "preto", 15):
                    Send("OCUPADO", 1)
                    SendBLE()
                    print("preto")
                    drive.straight(55)
                    drive.turn(-30 * lado_verde)
                    MoveAteCor(-500 * lado_verde, 500 * lado_verde, 150, sensorA)
                    drive.turn(-30 * lado_verde)
                    drive.straight(40)
                    break
    
    elif ComparaHsv(eColor, "red") and ComparaHsv(dColor, "red") and -5 < pitch < 5:
        hub.speaker.beep(850, 200)
        vermelho = True
        return True

    elif ComparaHsv(eColor, "prata", 5) and ComparaHsv(dColor, "prata", 5) and -5 < pitch < 5:
        print("prata")
        drive.stop()
        hub.speaker.beep(1000, 100)
        giro = MoveAteCor(-250,250, 60, sensorD)
        wait(100)
        if not giro == "Preto":
            drive.turn(35)
            Send("ESTADO", Estado.RESGATE)
            return True
        hub.speaker.beep(1000, 100)
        drive.turn(40)

    return False

def VerdeVerde():
    print("beco")
    while True:
        if not ComparaHsv(sensorD.hsv(), "green"):
            if ComparaHsv(sensorD.hsv(), "branco", 5):
                print("branco")
                break
            elif ComparaHsv(sensorD.hsv(), "preto", 25):
                Send("OCUPADO", 1)
                SendBLE()
                print("preto")
                drive.straight(30)
                drive.turn(180)
                drive.straight(20)
                break

def ChecaObstaculo(lado=1):
    Send("OCUPADO", 1)
    SendBLE()
    pitch = hub.imu.tilt()[0]
    distancia = ultraF.distance()
    if distancia <= 50 and -5 < pitch < 5:
        drive.stop()
        wait(250)
        if ultraF.distance() <= 50:
            drive.settings(300)
            #IDEIA PRA DEPOIS: Fazer ele se alinhar na linha antes de desviar
            ultra_preciso(100)
            drive.turn(90 * lado)
            drive.curve(140, -360 * lado, wait=False)
            while True:
                if ComparaHsv(sensorD.hsv(), "preto") or ComparaHsv(sensorE.hsv(), "preto"):
                    break
                wait(5)
            drive.straight(59)
            drive.turn(45 * lado)
            if lado == 1:
                MoveAteCor(-400, 400, 150, sensorD)
            else:
                MoveAteCor(400,-400, 150, sensorE)
    Send("OCUPADO", 0)

def Pid():
    global integral, last_error, pid_erro, preto_max, preto_min
    sensorA = sensorD
    sensorB = sensorE
    lado_preto = 1
    corE = sensorE.hsv()
    corD = sensorD.hsv()
    if ComparaHsv(corD, "preto", 12) and ComparaHsv(corE, "branco", 15) or ComparaHsv(corE, "preto", 12) and ComparaHsv(corD, "branco", 15):
        if ComparaHsv(corE, "preto", 12):
            sensorA = sensorE
            sensorB = sensorD
            lado_preto = -1
        timer_noventa.resume()
        drive.straight(45)
        giro = MoveAteCor(vel_virada * lado_preto, -vel_virada * lado_preto, 180, sensorB, cor="preto")
        if not giro:
            MoveAteCor(-vel_virada * lado_preto, vel_virada, 500, sensorA, cor="preto")
            MoveAteCor(vel_virada * lado_preto, -vel_virada, 500, sensorA, cor="branco", tolerance=7)
            drive.straight(-15)
            return
        MoveAteCor(-vel_virada * lado_preto, vel_virada * lado_preto, 500, sensorB, cor="branco", tolerance=7)
        drive.straight(-15)
    else:
        if timer_noventa.time() > 1000:
            timer_noventa.pause()
            timer_noventa.reset()
        pid_erro = sensorD.reflection() - sensorE.reflection()
        if ComparaHsv(sensorE.hsv(), "branco") and ComparaHsv(sensorD.hsv(), "branco"):
            pid_erro = 0
        proporcional = pid_erro * _KP
        integral += pid_erro * _KI
        derivado = (pid_erro - last_error) * _KD
        correcao = proporcional + integral + derivado
        negativeForce = abs(pid_erro) * erro_vel_factor
        motorE.run((forcaBase - negativeForce) - correcao)
        motorD.run((forcaBase - negativeForce) + correcao)
        last_error = pid_erro

def MoveAteCor(speed_left, speed_right, distance, sensorA, sensorB = None, cor = "preto", tolerance=20):
    global preto_max, preto_min
    motorE.reset_angle(0)
    motorD.reset_angle(0)

    target_angle = distance * (360 / (3.1416 * 30.9))

    while abs(motorE.angle()) < target_angle and abs(motorD.angle()) < target_angle:
        if sensorB == None:
            if ComparaHsv(sensorA.hsv(), cor, tolerance):
                return True
        else:
            if ComparaHsv(sensorA.hsv(), cor, tolerance) or ComparaHsv(sensorB.hsv(), cor, tolerance):
                return True
        motorE.run(speed_left)
        motorD.run(speed_right)

    motorE.stop()
    motorD.stop()
    return False

def Reta(speed_left,speed_right, distance, ultraDist = None, factor = None, sens = None, angle_motor = 180, sensorA = None, sensorB = None):
    motorE.reset_angle(0)
    motorD.reset_angle(0)

    target_angle = distance * (360 / (3.1416 * 30.9))
    #target_angle = distance * 3.19
    ultra_factor = 0

    while distance == 0 or abs(motorE.angle()) < target_angle and abs(motorD.angle()) < target_angle:
        # angle_percorrido = (abs(motorE.angle()) + abs(motorD.angle())) / 2
        # dist_percorrida = angle_percorrido / 3.19
        print("load: ", motorD.load())
        if sensorA:
            if sensorB == None:
                if ComparaHsv(sensorA.hsv(), "preto", 18):
                    drive.stop()
                    print("preto")
                    return "Preto"
            else:
                if ComparaHsv(sensorA.hsv(), "preto", 18) or ComparaHsv(sensorB.hsv(), "preto", 18):
                    drive.stop()
                    print("preto")
                    return "Preto"
        if ultraDist:
            if ultraF.distance() <= ultraDist:
                ultra_factor += 1
                if ultra_factor > factor:
                    drive.stop()
                    drive.straight(50)
                    print("parede")
                    return "Parede"
            else:
                ultra_factor = 0
        else:
            if abs(motorE.angle()) > angle_motor:
                diferencaA = abs(abs(motorE.speed()) - abs(speed_left))
                diferencaB = abs(abs(motorD.speed()) - abs(speed_right))
                if diferencaA > sens or diferencaB > sens:
                    drive.stop()
                    print("bateu")
                    return "Bateu"

        motorE.run(speed_left)
        motorD.run(speed_right)
        wait(100)

    drive.stop()
    print("distancia")
    return "Distancia"

def angle_preciso(angulo_desejado, velocidade=400, margem = 3):
    while True:
        angulo_atual = hub.imu.heading()# Atualiza o ângulo atual
        erro = angulo_desejado - angulo_atual 

        if abs(erro) < margem:  # Se o erro for menor que 2 graus, parar
            break

        # Controla a velocidade do motor proporcional ao erro
        velocidade_ajustada = velocidade if erro > 0 else -velocidade
        motorE.run(velocidade_ajustada)
        motorD.run(-velocidade_ajustada)
        
        wait(10)

    # Parar os motores
    motorE.stop()
    motorD.stop()
    wait(100)
    
def ultra_preciso(dist_desejada, velocidade=400, margem = 1):

    while True:
        dist_atual = ultraF.distance()  # Atualiza o ângulo atual
        erro = dist_desejada - dist_atual 

        if abs(erro) < margem:  # Se o erro for menor que 2 graus, parar
            break

        # Controla a velocidade do motor proporcional ao erro
        velocidade_ajustada = velocidade if erro < 0 else -velocidade
        motorE.run(velocidade_ajustada)
        motorD.run(velocidade_ajustada)
        
        wait(10)

    # Parar os motores
    motorE.stop()
    motorD.stop()
    wait(100)

def Resgate():
#Verifica se está no meio ou no canto----------------------------------------
    tipo_area = int.from_bytes(hub.system.storage(21, 1), 'big')
    print(tipo_area)
    if tipo_area == Area.VERTICAL:
        print("Vertical")
    elif tipo_area == Area.HORIZONTAL:
        print("Horizontal")
    else:
        print("Quadrado")

    saidaMeio = -1
    saidaCanto = [0.0, 0]
    drive.straight(220)
    drive.turn(90)
    lado = 0
    wait(250)
    if ultraF.distance() <= 120:
        lado = 1
        Reta(700, 700, 120, sens=190, sensorA=sensorE, sensorB=sensorD, angle_motor=90)
        drive.straight(-50)
    else:
        if ultraT.distance() <= 120:
            lado = -1
            Reta(-700, -700, 120, sens=210, sensorA=sensorE, sensorB=sensorD, angle_motor=90)
            drive.straight(50)

    print("lado: ", lado)
    girinho = 0
    hub.imu.reset_heading(-90)
    if tipo_area == Area.HORIZONTAL:
        girinho = lado * 55
    elif tipo_area == Area.VERTICAL:
        girinho = lado * 30
    else:
        girinho = lado * 45
    drive.turn(-90 + girinho)

    Send("GARRA", Garra.ABERTA)
    SendBLE()
    wait(500)

    if tipo_area == Area.VERTICAL and lado == 0:
        drive.straight(700)
    else:
        drive.straight(350 + abs(lado * 300))

    Send("GARRA", Garra.FECHADA)
    SendBLE()
    wait(750)

    if not lado == 0:
        if tipo_area == Area.HORIZONTAL:
            drive.turn(lado * 55)
        elif tipo_area == Area.VERTICAL:
            drive.turn(lado * 30)
        else:
            drive.turn(lado * 45)

    reta = 0

    if lado == 0:
        drive.turn(135)
        reta = tReta.CANTO
    else:
        drive.turn(90 * lado)
        reta = tReta.MEIO

    cantos = 0
    meios = 0
    tri_verde = 0
    tri_vermelho = 0
    x = 7
    for _ in range(x):
        Send("GARRA", Garra.ABERTA)
        SendBLE()
        wait(500)
        if reta == tReta.MEIO:
            retinha = Reta(700, 700, 0, ultraDist=210,factor=2, sensorA=sensorE, sensorB=sensorD)
            if retinha == "Parede":
                ultra_preciso(90, 200, 2.35)
                drive.straight(-20)
        else:
            retinha = Reta(700, 700, 385, ultraDist=230,factor=2)
            if retinha == "Parede":
                ultra_preciso(90, 200, 2.35)
                drive.straight(-20)
        Send("GARRA", Garra.FECHADA)
        SendBLE()
        wait(850)
        if reta == tReta.MEIO:
            if retinha == "preto":
                saidaMeio = meios
                drive.straight(-430)
            else:
                Reta(700, 700, 150, sens=210, angle_motor=180)
                if tipo_area == Area.QUADRADA:
                    drive.straight(-445)
                else:
                    retinha = meios + 1 if lado != 0 else meios
                    if retinha % 2 == tipo_area:
                        print("maior")
                        drive.straight(-630)
                    else:
                        print("menor")
                        drive.straight(-445)
        else:
            Reta(700, 700, 140, sens=200, angle_motor=180)
            wait(500)
            GetBLE()
            wait(100)
            if not Read("FCOR") == 0 and retinha == "Parede":
                print("canto triangulo")
                if Read("FCOR") == 1:
                    tri_verde = hub.imu.heading()
                elif Read("FCOR") == 2:
                    tri_vermelho = hub.imu.heading()


                if tipo_area == Area.QUADRADA:
                    drive.straight(-450)
                else:
                    drive.straight(-550)
                
            else:
                hub.speaker.beep(900, 100)
                angulo_saida = hub.imu.heading()
                print("canto: ", saidaCanto, "meio: ", saidaMeio)
                if saidaCanto[1] == 0 and saidaMeio < 0:
                    drive.turn(30)
                    wait(100)
                    if ultraF.distance() >= 200:
                        saidaCanto = [angulo_saida, -1]
                    drive.turn(-60)
                    wait(100)
                    if ultraF.distance() >= 200:
                        saidaCanto = [angulo_saida, 1]
                    drive.turn(30)  
                if tipo_area == Area.QUADRADA:
                    drive.straight(-550)
                else:
                    drive.straight(-550)

        if lado == -1:
            drive.turn(45)
        else:
            drive.turn(-45)
        
        reta = -reta
        if reta == tReta.MEIO:
            meios += 1
        else:
            cantos += 1

    print("saida meio: ", saidaMeio)
    print("saida canto: ", saidaCanto)
    print("tri_verde: ", tri_verde, "tri_vermelho: ", tri_vermelho)

    ladoSemZero = lado if lado != 0 else 1

    triangulo = tri_verde if tri_verde != 0 else tri_vermelho

    angle_preciso(triangulo - (180 * ladoSemZero))
    
    if tipo_area == Area.QUADRADA:
        drive.straight(-350)
    else:
        drive.straight(-400)
    Reta(-800, -800, 300, sens=210, angle_motor=180)
    Send("PORTA", Porta.ABERTA)
    SendBLE()
    wait(1000)
    Send("PORTA", Porta.FECHADA)
    SendBLE()
    if tipo_area == Area.QUADRADA:
        drive.straight(420)
    else:
        drive.straight(500)


    angle_preciso(saidaCanto[0])

    drive.straight(450)

    drive.turn(45 * saidaCanto[1])
    Reta(500, 500, 0, ultraDist=200,factor=2)
    ultra_preciso(90, 200, 2.35)
    drive.straight(50)
    drive.turn(-90 * saidaCanto[1])
    drive.straight(200)

    Send("ESTADO", Estado.PLAY)
    SendBLE()

def ChecaRampa():
    pitch = hub.imu.tilt()[0]
    if pitch > 10 and abs(hub.imu.angular_velocity(Axis.Z)) < 9:
        Send("GARRA", Garra.ABERTA)
    else:
        Send("GARRA", Garra.FECHADA)

def Play():
    global integral, last_error, vermelho
    integral = 0
    last_error = 0
    vermelho = False
    GetStoredColors(colors, colors_array)
    Send("ESTADO", Estado.PLAY)
    SetHubColor(0, 50)
    hub.system.set_stop_button([Button.CENTER])
    timer_noventa.reset()
    timer_noventa.pause()

    EsperaHubCima()

    while True:
        GetBLE()
        if vermelho:
            drive.stop()
            break

        if Send("ESTADO") == Estado.PLAY:
            drive.settings(forcaBase)
            ChecaObstaculo((int.from_bytes(hub.system.storage(20, 1), 'big') * 2) - 1)
            Send("OCUPADO", 0)
            if not ChecaCores():
                Pid()
            ChecaRampa()
        elif Send("ESTADO") == Estado.RESGATE:
            Resgate()

        SendBLE()

if __name__ == "__main__":
    print("ABRE MAIN-------------")
    while True:
        continue
        
