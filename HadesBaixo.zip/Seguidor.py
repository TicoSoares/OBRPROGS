from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch

#Define hub e canais de informação do bluetooth
hub = PrimeHub(broadcast_channel=2, observe_channels=[1])
hub.system.set_stop_button(Button.CENTER)
hub.speaker.volume(50)

#Define as Portas
sensorD = ColorSensor(Port.A)
sensorE = ColorSensor(Port.B)
ultra = UltrasonicSensor(Port.D)
motorD = Motor(Port.C)
motorE = Motor(Port.E, Direction.COUNTERCLOCKWISE)

#Define motores de movimento
drive = DriveBase(motorE, motorD, wheel_diameter=40, axle_track=200)
drive.settings(210, 100, 350, 210)

colors = [Color.GREEN,Color.GRAY,Color.BLACK,Color.WHITE]   

integral = 0
last_error = 0

forcaBase = 150
_KP = 10  # Este valor será ajustado para encontrar K_u
_KI = 0
_KD = 0.0

def ChecaVerde():
    eColor = sensorE.hsv()
    dColor = sensorD.hsv()
    if ComparaHsv(eColor, "green") or ComparaHsv(dColor, "green"):

        hub.speaker.beep(1000, 200)
        drive.stop()
        wait(500)
        drive.drive(150, 0)
        if ComparaHsv(eColor, "green"):
            print("esquerda")
            while True:

                if ComparaHsv(sensorD.hsv(), "green"):
                    print("2 verde")
                    VerdeVerde()
                    break
                if sensorE.hsv().h > 175:
                    if sensorE.hsv().v > 50:
                        print("branco")
                        break
                    elif sensorE.hsv().v <= 50:
                        print("preto")
                        drive.straight(40)
                        drive.turn(30)
                        GiraAtePreto(120, 150, sensorE)
                        drive.turn(15)
                        wait(10)
                        break
                wait(10)

        elif ComparaHsv(dColor, "green"): 
            print("direita")
            while True:
                if ComparaHsv(sensorE.hsv(), "green"):
                    VerdeVerde()
                    break
                if sensorD.hsv().h > 175:
                    if sensorD.hsv().v > 50:
                        print("branco")
                        break
                    elif sensorD.hsv().v <= 50:
                        print("preto")
                        drive.straight(40)
                        drive.turn(-30)
                        GiraAtePreto(-120, 150, sensorD)
                        drive.turn(-15)
                        wait(10)
                        break
                wait(10)

def VerdeVerde():
    print("beco")   
    while True:
        if sensorD.hsv().h > 175:
            if sensorD.hsv().v > 50:
                print("branco")
                break
            elif sensorD.hsv().v <= 50:
                print("preto")
                drive.straight(30)
                drive.turn(-135)
                GiraAtePreto(-150, 150, sensorD)
                drive.turn(-15)
                wait(10)
                break
        wait(10)

def ChecaObstaculo(lado=1):
    if ultra.distance() <= 50:
        drive.stop()
        drive.turn(-90 * lado)
        drive.straight(220)
        drive.turn(90 * lado)
        x = 3
        for _ in range(x):
            if MoveAtePreto(210, 210, 250, sensorE, sensorD):
                drive.straight(80)
                drive.turn(-45 * lado)
                if lado == 1:
                    GiraAtePreto(-150 * lado, 150, sensorD)
                else:
                    GiraAtePreto(-150 * lado, 150, sensorE)

                drive.turn(-20 * lado)
                drive.straight(-25)
                drive.stop()
                return
            else:
                drive.straight(200)
                drive.turn(97 * lado)      

def Pid():
    global integral, last_error  
    erro = sensorE.reflection() - sensorD.reflection()
    proporcional = erro * _KP
    integral += erro * _KI
    derivado = (erro - last_error) * _KD
    correcao = proporcional + integral + derivado
    motorE.run(forcaBase - correcao)
    motorD.run(forcaBase + correcao)
    last_error = erro

def ComparaHsv(hsv, color, tolerancia = 30):
    color_index = 0
    if color == "prata":
        color_index = 1
    elif color == "black":
        color_index = 2
    elif color == "white":
        color_index = 3
    
    hresult = abs(hsv.h - colors[color_index].h) <= tolerancia
    sresult = abs(hsv.s - colors[color_index].s) <= tolerancia
    vresult = abs(hsv.v - colors[color_index].v) <= tolerancia
    return hresult and sresult and vresult

def GetStoredColors(colors):
    stored_colors = [v for v in hub.system.storage(0, read=6)]
    colors[0] = Color(stored_colors[0], stored_colors[1], stored_colors[2])
    colors[1] = Color(stored_colors[3], stored_colors[4], stored_colors[5])
    print(colors)

def CheckStopButton():
    pressed = hub.buttons.pressed()
    return Button.CENTER in pressed

def MoveAtePreto(speed_left, speed_right, distance, sensorA, sensorB = None):
    motorE.reset_angle(0)
    motorD.reset_angle(0)
    
    target_angle = distance * (360 / (3.1416 * 36))

    while abs(motorE.angle()) < target_angle and abs(motorD.angle()) < target_angle:
        if sensorB == None:
            if sensorA.reflection() < 50:
                return True
        else:
            if sensorA.reflection() < 50 or sensorB.reflection() < 50:
                return True
        motorE.run(speed_left)
        motorD.run(speed_right)

    motorE.stop()
    motorD.stop()
    return False

def GiraAtePreto(speed, distance, sensorA, sensorB = None):
    motorE.reset_angle(0)
    motorD.reset_angle(0)
    
    target_angle = distance * (360 / (3.1416 * 36))

    while abs(motorE.angle()) < target_angle and abs(motorD.angle()) < target_angle:
        if sensorB == None:
            if sensorA.reflection() < 50:
                break
        else:
            if sensorA.reflection() < 50 or sensorB.reflection() < 50:
                break
        motorE.run(speed)
        motorD.run(-speed)
    
    hub.speaker.beep(900, 200)
    motorE.stop()
    motorD.stop()

def Seguidor():

    GetStoredColors(colors)

    while True:
        # if CheckStopButton():
        #     drive.stop()
        #     break

        ChecaObstaculo(-1)
        ChecaVerde()
        Pid()
        # print("E: " + str(sensorE.reflection()) + " D: " + str(sensorD.reflection()))
        # print("E: " + str(sensorE.hsv()) + " D: " + str(sensorD.hsv()))
        # if sensorE.hsv().h < 175 or sensorD.hsv().h < 175:
        #     print("verde?")
        # print(ultra.distance())

Seguidor()