from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor, ForceSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch

hub = PrimeHub()

sensorD = ColorSensor(Port.A)
sensorE = ColorSensor(Port.C)
ultra = UltrasonicSensor(Port.E)
motorD = Motor(Port.B, Direction.COUNTERCLOCKWISE)
motorE = Motor(Port.D)

pid_erro = 0
integral = 0
last_error = 0

erro_vel_factor = 3.1
forcaBase = 280
_KP = 11.3
_KI = 0.0
_KD = 8.0

while True:
    pid_erro = sensorD.reflection() - sensorE.reflection()
    if sensorE.reflection() > 60 and sensorD.reflection() > 60:
        pid_erro = 0
    proporcional = pid_erro * _KP
    integral += pid_erro * _KI
    derivado = (pid_erro - last_error) * _KD
    correcao = proporcional + integral + derivado
    negativeForce = abs(pid_erro) * erro_vel_factor
    motorE.run((forcaBase - negativeForce) - correcao)
    motorD.run((forcaBase - negativeForce) + correcao)
    last_error = pid_erro