from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor
from pybricks.parameters import Button, Color, Direction, Port, Axis
from pybricks.robotics import DriveBase
from pybricks.tools import wait

from ExtraTools import *

sensorD = ColorSensor(Port.A)
sensorE = ColorSensor(Port.C)
ultraF = UltrasonicSensor(Port.F)
ultraT = UltrasonicSensor(Port.E)
motorD = Motor(Port.B, Direction.COUNTERCLOCKWISE)
motorE = Motor(Port.D)
drive = DriveBase(motorE, motorD, 30.9, 137.5)
drive.settings()
default_settings = drive.settings()
drive.settings(539.9999, 5393.99, 100)
fast_settings = drive.settings()
drive.use_gyro(True)

colors = {
    "green": Color.GREEN,
    "prata": Color.VIOLET,
    "red": Color.RED,
    "preto": Color.BLACK,
    "branco": Color.WHITE
}
colors_copy = colors.copy()
colors_array = ["green", "prata", "red", "branco"]

pid_erro = 0
integral = 0
last_error = 0

vermelho = False

erro_vel_factor = 0
forcaBase = 350
vel_virada = 400
_KP = 11
_KI = 0.0
_KD = 7
tamanho_garra = 110
raio_obs = 35.0
margem_obs = 53.0
raio_robo = 84.0
total_raio = raio_obs + margem_obs + raio_robo

contador_retas_temp = 1

timer_noventa = StopWatch()
timer_noventa.pause()

historico_angulos = []  # Histórico de ângulos
tamanho_janela = 10  # Janela de leituras (ajustável)
angulo_medio = 0  # Ângulo médio atualizado
intervalo_leitura = StopWatch()  # Cronômetro para controlar leituras

def atualizar_angulo_medio():
    global angulo_medio, historico_angulos

    if intervalo_leitura.time() >= 20:  # Verificação a cada 20ms
        intervalo_leitura.reset()
        
        # Adiciona a nova leitura de ângulo ao histórico
        angulo_atual = hub.imu.tilt()[0]
        historico_angulos.append(angulo_atual)

        # Remove leituras antigas se a janela for excedida
        if len(historico_angulos) > tamanho_janela:
            historico_angulos.pop(0)

        # Cálculo da Média Móvel Ponderada
        pesos = range(1, len(historico_angulos) + 1)  # Pesos crescentes
        angulo_medio = sum(a * p for a, p in zip(historico_angulos, pesos)) / sum(pesos)

def AnotaCor():
    global colors_note

    Send("ESTADO", Estado.COR)
    hub.display.off()

    menu_keys = colors_array
    menu_index = 0

    selected = menu_keys[menu_index]
    hub.light.on(colors_copy[selected])

    array_colors = hub.system.storage(0, read=20) 

    while True:
        result = GetButton()
        pressed = time_pressed = None
        if result is None:
            break
        else:
            pressed, time_pressed = result
            if Button.CENTER in pressed:
                if time_pressed > 500:
                    break
                else:
                    colorE = sensorE.hsv()
                    colorD = sensorD.hsv()

                    if selected == "branco":
                        print("branco :", colorE, "preto :", colorD)
                        array_colors = array_colors[:12] + hsv_to_bytes(colorD) + hsv_to_bytes(colorE)
                    else:
                        start_index = menu_index * 4
                        array_colors = array_colors[:start_index] + hsv_to_bytes(colorD) + array_colors[start_index + 4:]
                        print(selected, ":", colorD)

                    hub.system.storage(0, write=array_colors)
                    print(hub.system.storage(0, read=20))

            elif Button.LEFT in pressed:
                menu_index = (menu_index - 1) % len(menu_keys)
            elif Button.RIGHT in pressed:
                menu_index = (menu_index + 1) % len(menu_keys)

            selected = menu_keys[menu_index]
            hub.light.on(colors_copy[selected])
                
def ComparaHsv(hsv, color_name, sens=20):
    color = colors[color_name]
    hresult = abs(hsv.h - color.h) <= sens
    sresult = abs(hsv.s - color.s) <= sens
    vresult = abs(hsv.v - color.v) <= sens
    return hresult and sresult and vresult

def ChecaCores():
    eColor = sensorE.hsv()
    dColor = sensorD.hsv()
    pitch = hub.imu.tilt()[0]

    if (ComparaHsv(eColor, "green") or ComparaHsv(dColor, "green")) and -5 < pitch < 5 and timer_noventa.time() == 0:
        sensorA = sensorD
        sensorB = sensorE
        lado_verde = -1
        print("verde")
        hub.speaker.beep(1000, 200)
        drive.stop()
        wait(500)
        drive.drive(60, 0)
        if ComparaHsv(eColor, "green") and ComparaHsv(dColor, "green"):
            print("verde BECO")
            VerdeVerde()
        elif ComparaHsv(eColor, "green"):
            sensorA = sensorE
            sensorB = sensorD
            lado_verde = 1
        
        drive.turn(15 * lado_verde)
        drive.straight(-15)
        drive.drive(60, 0)
        while True:
            # Verifica dnv se é verde verde caso tenha passado e n viu
            if ComparaHsv(sensorB.hsv(), "green"):
                print("verde verde")
                VerdeVerde()
                break
            if not ComparaHsv(sensorA.hsv(), "green"):
                if ComparaHsv(sensorA.hsv(), "branco", 10):
                    drive.turn(-25*lado_verde)
                    print("branco")
                    break
                elif ComparaHsv(sensorA.hsv(), "preto", 15):
                    Send("OCUPADO", 1)
                    SendBLE()
                    print("preto")
                    drive.straight(55)
                    drive.turn(-30 * lado_verde)
                    MoveAteCor(-500 * lado_verde, 500 * lado_verde, 150, sensorA)
                    drive.turn(-30 * lado_verde)
                    drive.straight(40)
                    break
    
    elif ComparaHsv(eColor, "red") and ComparaHsv(dColor, "red") and -5 < pitch < 5:
        hub.speaker.beep(850, 200)
        vermelho = True
        return True

    elif ComparaHsv(eColor, "prata", 5) and ComparaHsv(dColor, "prata", 5) and -5 < pitch < 5:
        print("prata")
        drive.stop()
        hub.speaker.beep(1000, 100)
        hub.imu.reset_heading(0)
        giro = MoveAteCor(-250,250, 60, sensorD)
        wait(100)
        if not giro == "Preto":
            drive.turn(-hub.imu.heading())
            Send("ESTADO", Estado.RESGATE)
            return True
        hub.speaker.beep(1000, 100)
        drive.turn(-hub.imu.heading())

    return False

def VerdeVerde():
    print("beco")
    while True:
        if not ComparaHsv(sensorD.hsv(), "green"):
            if ComparaHsv(sensorD.hsv(), "branco", 5):
                print("branco")
                break
            elif ComparaHsv(sensorD.hsv(), "preto", 25):
                Send("OCUPADO", 1)
                SendBLE()
                print("preto")
                drive.straight(30)
                drive.turn(180)
                drive.straight(20)
                break

def ChecaObstaculo():
    global total_raio, margem_obs
    lado = 1
    Send("OCUPADO", 1)
    SendBLE()
    pitch = hub.imu.tilt()[0]
    distancia = ultraF.distance()
    if distancia <= 50 and -5 < pitch < 5:
        drive.stop()
        wait(250)
        if ultraF.distance() <= 50:
            #IDEIA PRA DEPOIS: Fazer ele se alinhar na linha antes de desviar
            ultra_preciso(60, 100)
            drive.turn(90 * lado)
            hub.imu.reset_heading(0)
            Curva(total_raio, -360 * lado, wait=False)
            while not ComparaHsv(sensorD.hsv(), "preto") and not ComparaHsv(sensorE.hsv(), "preto"):
                if abs(motorE.load()) > 180 or abs(motorD.load()) > 180:
                    drive.stop()
                    Curva(-total_raio, -hub.imu.heading())
                    drive.turn(-180 * lado)
                    hub.imu.reset_heading(0)
                    lado = -lado
                    Curva(total_raio, -360 * lado, wait=False)
                wait(5)
            drive.straight(35)
            drive.turn(45 * lado)
            if lado == 1:
                MoveAteCor(400, -400, 150, sensorD)
                MoveAteCor(400, -400, 150, sensorD, cor="branco", tolerance=7)
            else:
                MoveAteCor(-400, 400, 150, sensorE)
                MoveAteCor(-400, 400, 150, sensorE, cor="branco", tolerance=7)
            
            drive.turn(15 * lado)
    Send("OCUPADO", 0)

def Seguidor():
    global integral, last_error, pid_erro, _KP
    sensorA = sensorD
    sensorB = sensorE
    lado_preto = 1
    corE = sensorE.hsv()
    corD = sensorD.hsv()
    atualizar_angulo_medio()

    if -17 < angulo_medio < 10:
        if ComparaHsv(corD, "preto", 12) and ComparaHsv(corE, "branco", 15) or ComparaHsv(corE, "preto", 12) and ComparaHsv(corD, "branco", 15):
            Logica90(corE, corD, lado_preto, sensorA, sensorB)
    else:
        volume = hub.speaker.volume()
        hub.speaker.volume(60)
        hub.speaker.beep(90, 100)
        hub.speaker.volume(volume)

    if angulo_medio <= -10:
        kp = _KP
        _KP = 6
        PidSeguidor(forcaBase-200)
        _KP = kp
    else:
        PidSeguidor(forcaBase)

def Logica90(corE, corD, lado_pretin, sensorA, sensorB):
    global integral, last_error, pid_erro, vel_virada
    lado_preto = lado_pretin
    if ComparaHsv(corE, "preto", 12):
        sensorA = sensorE
        sensorB = sensorD
        lado_preto = -1
    timer_noventa.resume()
    drive.straight(35)
    if ComparaHsv(sensorA.hsv(), "green") or ComparaHsv(sensorB.hsv(), "green"):
        drive.straight(40)
        return
    giro = MoveAteCor(vel_virada * lado_preto, -vel_virada * lado_preto, 190, sensorB, cor="preto")
    if not giro:
        MoveAteCor(-vel_virada * lado_preto, vel_virada * lado_preto, 500, sensorA, cor="preto")
        MoveAteCor(vel_virada * lado_preto, -vel_virada * lado_preto, 500, sensorA, cor="branco", tolerance=7)
        drive.straight(-10)
        return
    MoveAteCor(-vel_virada * lado_preto, vel_virada * lado_preto, 500, sensorB, cor="branco", tolerance=7)
    drive.turn(-5 * lado_preto)
    drive.straight(-10)

def PidSeguidor(vel):
    global integral, last_error, pid_erro
    if timer_noventa.time() > 1000:
        timer_noventa.pause()
        timer_noventa.reset()
    pid_erro = sensorD.reflection() - sensorE.reflection()
    if ComparaHsv(sensorE.hsv(), "branco") and ComparaHsv(sensorD.hsv(), "branco"):
        pid_erro = 0
    proporcional = pid_erro * _KP
    integral += pid_erro * _KI
    derivado = (pid_erro - last_error) * _KD
    correcao = proporcional + integral + derivado
    negativeForce = abs(pid_erro) * erro_vel_factor
    motorE.run((vel - negativeForce) - correcao)
    motorD.run((vel - negativeForce) + correcao)
    last_error = pid_erro

def MoveAteCor(speed_left, speed_right, distance, sensorA, sensorB = None, cor = "preto", tolerance=20):
    global preto_max, preto_min
    motorE.reset_angle(0)
    motorD.reset_angle(0)

    target_angle = distance * (360 / (3.1416 * 30.9))

    while abs(motorE.angle()) < target_angle and abs(motorD.angle()) < target_angle:
        if sensorB == None:
            if ComparaHsv(sensorA.hsv(), cor, tolerance):
                return True
        else:
            if ComparaHsv(sensorA.hsv(), cor, tolerance) or ComparaHsv(sensorB.hsv(), cor, tolerance):
                return True
        motorE.run(speed_left)
        motorD.run(speed_right)

    motorE.stop()
    motorD.stop()
    return False

def ultraReta(speed, distance, ultraDist, factor, sensorA, sensorB=None):
    motorE.reset_angle(0)
    motorD.reset_angle(0)
    ultra_factor = 0
    drive.reset()
    while distance == 0 or abs(drive.distance()) < distance:
        if sensorA:
            if sensorB == None:
                if ComparaHsv(sensorA.hsv(), "preto", 18):
                    drive.stop()
                    print("preto")
                    return "Preto"
            else:
                if ComparaHsv(sensorA.hsv(), "preto", 18) or ComparaHsv(sensorB.hsv(), "preto", 18):
                    drive.stop()
                    print("preto")
                    return "Preto"
        if ultraDist:
            if ultraF.distance() <= ultraDist:
                ultra_factor += 1
                if ultra_factor > factor:
                    drive.stop()
                    drive.straight(50)
                    print("parede")
                    return "Parede"
            else:
                ultra_factor = 0

        motorE.run(speed)
        motorD.run(speed)
        wait(5)

    drive.stop()
    print("distancia")
    return "Distancia"

def Reta(speed_left,speed_right, distance, sens = None, sensorA = None, sensorB = None):
    motorE.reset_angle(0)
    motorD.reset_angle(0)
    ultra_factor = 0
    drive.reset()
    while distance == 0 or abs(drive.distance()) < distance:
        if sensorA:
            if sensorB == None:
                if ComparaHsv(sensorA.hsv(), "preto", 13):
                    drive.stop()
                    print("preto")
                    return "Preto"
            else:
                if ComparaHsv(sensorA.hsv(), "preto", 13) or ComparaHsv(sensorB.hsv(), "preto", 13):
                    drive.stop()
                    print("Preto")
                    return "Preto"
        # print(f"DLoad: {motorD.load()} ELoad: {motorE.load()}")
        if abs(motorD.load()) > sens and abs(motorE.load()) > sens:
            drive.stop()
            print("bateu")
            return "Bateu"

        motorE.run(speed_left)
        motorD.run(speed_right)
        wait(5)

    drive.stop()
    print("distancia")
    return "Distancia"

def angle_preciso(angulo_desejado, velocidade=400, margem = 3):
    while True:
        angulo_atual = hub.imu.heading()# Atualiza o ângulo atual
        erro = angulo_desejado - angulo_atual 

        if abs(erro) < margem:  # Se o erro for menor que 2 graus, parar
            break

        # Controla a velocidade do motor proporcional ao erro
        velocidade_ajustada = velocidade if erro > 0 else -velocidade
        motorE.run(velocidade_ajustada)
        motorD.run(-velocidade_ajustada)
        
        wait(10)

    # Parar os motores
    motorE.stop()
    motorD.stop()
    wait(100)
    
def ultra_preciso(dist_desejada, velocidade=400, margem = 1, ultra=ultraF):
    while True:
        dist_atual = ultra.distance()  # Atualiza o ângulo atual
        erro = dist_desejada - dist_atual 

        if abs(erro) < margem:  # Se o erro for menor que 2 graus, parar
            break

        # Controla a velocidade do motor proporcional ao erro
        velocidade_ajustada = velocidade if erro < 0 else -velocidade
        motorE.run(velocidade_ajustada)
        motorD.run(velocidade_ajustada)
        
        wait(10)

    # Parar os motores
    motorE.stop()
    motorD.stop()
    wait(100)

def Curva(raio, angle, wait=True):
    drive.settings(*default_settings)
    drive.curve(raio, angle, wait=wait)
    drive.settings(*fast_settings)

def RetaResgate(dist = 0, speed_left = 700, speed_right=700):
    global contador_retas_temp 
    wait(250)
    if ultraF.distance() <= 120 or ultraT.distance() <= 90:
        print("a")
        Reta(-700, -700, 75, 100)
    Send("GARRA", Garra.ABERTA)
    SendBLE()
    wait(750)
    contador_retas_temp += 1
    reta = Reta(speed_left, speed_right, dist, sens=120, sensorA=sensorE, sensorB=sensorD)
    print(f"reta: {reta} {contador_retas_temp}")
    Send("GARRA", Garra.FECHADA)
    SendBLE()
    if dist == 0:
        drive.straight(-20)
    wait(750)
    if reta == "Preto" or reta == "Prata":
        drive.straight(-90)
    else:
        if dist == 0:
            Reta(speed_left, speed_right, 100, 185)
            drive.straight(-25)

def Resgate():
#Verifica se está no meio ou no canto----------------------------------------
    vel_reta = 700
    drive.straight(150)
    drive.turn(90)
    lado_zigzag = 1
    while True:
        RetaResgate(0, vel_reta, vel_reta)
        drive.turn(-90 * lado_zigzag)
        RetaResgate(100, vel_reta, vel_reta)
        drive.turn(-90 * lado_zigzag)
        lado_zigzag = -lado_zigzag

    Send("ESTADO", Estado.PLAY)
    SendBLE()

def ChecaRampa():
    pitch = hub.imu.tilt()[0]
    if pitch > 10 and abs(hub.imu.angular_velocity(Axis.Z)) < 9:
        Send("GARRA", Garra.ABERTA)
    else:
        Send("GARRA", Garra.FECHADA)

def Play():
    global integral, last_error, vermelho
    integral = 0
    last_error = 0
    vermelho = False
    GetStoredColors(colors, colors_array)
    Send("ESTADO", Estado.PLAY)
    SetHubColor(0, 50)
    hub.system.set_stop_button([Button.CENTER])
    timer_noventa.reset()
    timer_noventa.pause()

    EsperaHubCima()

    while True:
        GetBLE()
        if vermelho:
            drive.stop()
            break

        if Send("ESTADO") == Estado.PLAY:
            drive.settings(forcaBase)
            #ChecaObstaculo((int.from_bytes(hub.system.storage(20, 1), 'big') * 2) - 1)
            ChecaObstaculo()
            Send("OCUPADO", 0)
            if not ChecaCores():
                Seguidor()
        elif Send("ESTADO") == Estado.RESGATE:
            Resgate()

        SendBLE()

if __name__ == "__main__":
    print("main")
