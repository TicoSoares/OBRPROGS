from pybricks.hubs import PrimeHub
from pybricks.parameters import Button, Color, Port
from pybricks.tools import wait, StopWatch
from pybricks.iodevices import PUPDevice
from uerrno import ENODEV


hub = PrimeHub()
timer = StopWatch()

class Cima:
    BLE = 52

    ESTADO = 0
    WAITING = 1
    OCUPADO = 2
    GARRA = 3
    FCOR = 4
    TCOR = 5

    SIZE = 6

class Baixo:
    BLE = 51

    ESTADO = 0
    WAITING = 1
    OCUPADO = 2
    GARRA = 3
    ULTRA = 4
    PRETOPRETO = 5

    SIZE = 6

class Estado:
    MAIN = 0
    PLAY = 1
    RESGATE = 2
    COR = 3

class Garra:
    NONE = 0
    FECHADA = 1
    BAIXA = 2
    ABERTA = 3

thisHub = Cima if hub.system.name() == "HADES" else Baixo
otherHub = Baixo if hub.system.name() == "HADES" else Cima

sendData = bytearray(thisHub.SIZE)
readData = bytearray(otherHub.SIZE)

hub = PrimeHub(broadcast_channel=thisHub.BLE, observe_channels=[otherHub.BLE])
hub.speaker.volume(40)
hub.system.set_stop_button([Button.LEFT, Button.CENTER])

def Read(attr=None):
    global readData, otherHub
    if attr is None:
        return readData
    else:
        return readData[getattr(otherHub, attr)]

def GetBLE():
    global readData, otherHub
    try:
        data = hub.ble.observe(otherHub.BLE)
        if data:
            readData = bytearray(data)
        else:
            return None
    except Exception as e:
        print(f"Error observing BLE data: {e}")
        return None

def Send(attr=None, value=None):
    global sendData, thisHub
    if attr is None:
        return sendData
    else:
        if value is None:
            return sendData[getattr(thisHub, attr)]
        else:
            sendData[getattr(thisHub, attr)] = value

def SendBLE():
    global sendData
    hub.ble.broadcast(sendData)

def WaitTheOtherHub():
    while CheckStopButton():
        wait(5)
    while True:
        GetBLE()
        if Read("ESTADO") != Send("ESTADO"):
            Send("WAITING", 1)
        else:
            Send("WAITING", 0)
            break

        if CheckStopButton():
            return

        SendBLE()
        wait(5)

def GetButton():
    pressed = ()
    while not pressed:
        pressed = hub.buttons.pressed()
        GetBLE()
        if Read("ESTADO") != Send("ESTADO"):
            # if Read("WAITING") == 1 and Send("WAITING") == 0:
            if Read("WAITING") == 1:
                return None
            else:
                Send("WAITING", 1)
        SendBLE()
        wait(10)
    timer.reset()
    timer.resume()

    while hub.buttons.pressed():
        GetBLE()
        if not Read("ESTADO") == Send("ESTADO"):
            if Read("WAITING") == 1 and Send("WAITING") == 1:
                return None
            else:
                Send("WAITING", 1)
        SendBLE()
        wait(10)
    timer.pause()

    return pressed, timer.time()

def CheckStopButton():
    return Button.CENTER in hub.buttons.pressed()

def SetHubColor(h, v=100):
    new_color = Color(h, 100, v)
    hub.light.on(new_color)

def BlinkHubColor(h, v=100):
    new_color = Color(h, 100, v)
    hub.light.blink(new_color, [250, 250])

def hsv_to_bytes(hsv):
    # Ajustar o valor de Hue para caber em 2 bytes (0-65535)
    h_int = int(hsv.h / 360 * 65535)
    h_bytes = h_int.to_bytes(2, 'big')

    # Saturation e Value já estão entre 0 e 100, ajustar para caber em 1 byte (0-255)
    s_byte = int(hsv.s / 100 * 255).to_bytes(1, 'big')
    v_byte = int(hsv.v / 100 * 255).to_bytes(1, 'big')

    return h_bytes + s_byte + v_byte

def bytes_to_hsv(hsv_bytes):
    # Extrair os bytes de Hue (2 bytes), Saturation (1 byte) e Value (1 byte)
    h_int = int.from_bytes(hsv_bytes[0:2], 'big')
    s_byte = int.from_bytes(hsv_bytes[2:3], 'big')
    v_byte = int.from_bytes(hsv_bytes[3:4], 'big')

    # Converter de volta para os valores originais
    h = h_int / 65535 * 360
    s = s_byte / 255 * 100
    v = v_byte / 255 * 100

    return Color(round(h), round(s), round(v))

def GetStoredColors(colors):
    stored_colors = []

    x = 0
    for _ in range(len(colors)):
        hsv_bytes = hub.system.storage(x, read=4)
        stored_colors.append(bytes_to_hsv(hsv_bytes))
        x += 4

    for key, color in zip(colors.keys(), stored_colors):
        colors[key] = color

    print(colors)

device_names = {
    48: "SPIKE Medium Angular Motor",
    49: "SPIKE Large Angular Motor",
    # pybricks.pupdevices.ColorSensor
    61: "SPIKE Color Sensor",
    # pybricks.pupdevices.UltrasonicSensor
    62: "SPIKE Ultrasonic Sensor",
    # pybricks.pupdevices.ForceSensor
    63: "SPIKE Force Sensor",
}

ports = [Port.A, Port.B, Port.C, Port.D, Port.E, Port.F]

def SeePorts():
    # Go through all available ports.
    for port in ports:
        # Try to get the device, if it is attached.
        try:
            device = PUPDevice(port)
        except OSError as ex:
            if ex.args[0] == ENODEV:
                # No device found on this port.
                print(port, ": ---")
                continue
            else:
                raise

        # Get the device id
        id = device.info()["id"]

        # Look up the name.
        try:
            print(port, ":", device_names[id])
        except KeyError:
            print(port, ":", "Dispositivo não reconhecido com id: ", id)

# __all__ = ["hub", "Cima", "Baixo", "Estado", "thisHub",
# "otherHub", "Garra", "GetButton",
# "Read", "Send", "GetBLE", "SendBLE", "CheckStopButton",
# "hsv_to_bytes", "bytes_to_hsv", "WaitTheOtherHub",
# "GetStoredColors"]