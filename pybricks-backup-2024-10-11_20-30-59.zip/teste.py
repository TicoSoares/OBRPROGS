from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor, ForceSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch

hub = PrimeHub()

motorD = Motor(Port.B, Direction.COUNTERCLOCKWISE)
motorE = Motor(Port.D)
drive = DriveBase(motorE, motorD, 30.9, 137.5)
# drive.settings(turn_acceleration=400, turn_rate=400)
drive.curve(150, 90)