from pybricks.hubs import PrimeHub
from pybricks.parameters import Button, Color
from pybricks.tools import wait

hub = PrimeHub()

def GetButton()
    pressed = ()
    while not pressed:
        pressed = hub.buttons.pressed()
        wait(10)

    # Wait for the button to be released.
    while hub.buttons.pressed():
        wait(10)

    return pressed

def SetHubColor(h, v=100):
    new_color = Color(hvalue, 100, v)
    hub.light.on(new_color)