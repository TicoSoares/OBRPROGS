from pybricks.hubs import PrimeHub
from pybricks.pupdevices import ColorSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.tools import wait, StopWatch

hub = PrimeHub()

sensorD = ColorSensor(Port.A)

hub.light.on()

def AnotaCor():
    while True:

        hsv = [v for v in sensorD.hsv()]

        if Button.CENTER in botaoPress:
            break
        # Anota Fita Prata
        elif Button.LEFT in botaoPress:
            hub.system.storage(3, write=bytes(hsv))
            print("Prata: " + str(hsv))
        # Anota Fita VERDE
        elif Button.RIGHT in botaoPress:
            hub.system.storage(0, write=bytes(hsv))
            print("Verde: " + str(hsv))
        
        wait(500)