from pybricks.pupdevices import Motor, ColorSensor
from pybricks.parameters import Button, Color, Port
from pybricks.tools import wait

from ExtraTools import *

motorGarra = Motor(Port.F)
motorPorta = Motor(Port.B)
sensorF = ColorSensor(Port.D)
sensorT = ColorSensor(Port.C)

colors = {
    "green": Color.GREEN,
    "red": Color.RED
}
colors_note = colors.copy()

def AnotaCor():
    global colors_note
    print("anotaCor")

    Send("ESTADO", Estado.COR)
    hub.display.off()

    menu_keys = list(colors_note.keys())
    menu_index = 0
    selected = menu_keys[menu_index]
    hub.light.on(colors_note[selected])

    while True:
        result = GetButton()
        pressed = time_pressed = None
        if result is None:
            break
        else:
            pressed, time_pressed = result

        if result is not None:
            pressed, time_pressed = result
            if Button.CENTER in pressed:
                if time_pressed > 1000:
                    break
                else:
                    colorF = sensorF.hsv()
                    sFbytes = hsv_to_bytes(colorF)

                    offset = menu_keys.index(selected) * 4
                    hub.system.storage(offset, write=sFbytes)
                    print(selected + "Byte:", sFbytes)
                    print(selected + "Decode:", bytes_to_hsv(sFbytes))

            elif Button.LEFT in pressed:
                menu_index = (menu_index - 1) % len(menu_keys)
            elif Button.RIGHT in pressed:
                menu_index = (menu_index + 1) % len(menu_keys)

            selected = menu_keys[menu_index]
            hub.light.on(colors_note[selected])

def ComparaHsv(hsv, color_name, sens=30):
    color = colors[color_name]
    hresult = abs(hsv.h - color.h) <= sens
    sresult = abs(hsv.s - color.s) <= sens
    vresult = abs(hsv.v - color.v) <= sens
    return hresult and sresult and vresult

def SetGarra(garraState):
    target_angles = {2: -183, 3: -255}
    target_angle = target_angles.get(garraState, 0)
    diferenca = abs(motorGarra.angle()) - abs(target_angle)
    if abs(diferenca) < 5:
        return
    motorGarra.run_target(225, target_angle)

def Seguidor():
    pitch = hub.imu.tilt()[0]
    if Read("GARRA") == Garra.NONE:
        if pitch < -20:
            Send("GARRA", Garra.BAIXA)
        elif -5 < pitch < 5:
            Send("GARRA", Garra.FECHADA)
    else:
        Send("GARRA", Read("GARRA"))

    SetGarra(Send("GARRA"))

def Resgate():
    pass

def Play():

    Send("GARRA", Garra.FECHADA)
    Send("ESTADO", Estado.PLAY)

    motorGarra.reset_angle(0)
    GetStoredColors(colors)

    WaitTheOtherHub()

    while True:
        GetBLE()
        print(Read())

        if CheckStopButton() or Read("ESTADO") == Estado.MAIN:
            motorGarra.stop()
            motorPorta.stop()
            break

        if not Read("OCUPADO"):
            if Send("ESTADO") == Estado.PLAY:
                Seguidor()
            elif Send("ESTADO") == Estado.RESGATE:
                Resgate()

        SendBLE()
        wait(100)

if __name__ == "__main__":
    from Main import Start
    Start(1)
